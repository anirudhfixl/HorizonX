"use client";

import React, { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { MOCK_TOKENS } from "@/lib/mock-data";
import type { Token, TokenMarketData } from "@/types";
import { Search, ArrowUpRight, TrendingUp, TrendingDown, Activity, Globe2, BarChart3, SlidersHorizontal, Star } from "lucide-react";
import "./nexora-token-pages.css";

type T = Token & { market: TokenMarketData };
const tokens = MOCK_TOKENS as T[];
const money = (n?: number) => {
  if (n == null) return "—";
  if (n >= 1e12) return `$${(n/1e12).toFixed(2)}T`;
  if (n >= 1e9) return `$${(n/1e9).toFixed(2)}B`;
  if (n >= 1e6) return `$${(n/1e6).toFixed(2)}M`;
  if (n >= 1e3) return `$${(n/1e3).toFixed(2)}K`;
  return `$${n.toFixed(n < .01 ? 5 : 2)}`;
};
const compact = (n?: number) => n == null ? "—" : Intl.NumberFormat("en-US",{notation:"compact",maximumFractionDigits:2}).format(n);
const change = (n?: number) => `${(n ?? 0) >= 0 ? "+" : ""}${(n ?? 0).toFixed(2)}%`;
const networks = ["All networks", ...Array.from(new Set(tokens.map(t => t.network)))];

export function NexoraTokenDirectory() {
  const [query,setQuery] = useState("");
  const [network,setNetwork] = useState("All networks");
  const [sort,setSort] = useState<"marketCap"|"volume24h"|"priceChange24h"|"price"|"name">("marketCap");
  const [ascending,setAscending] = useState(false);
  const [direction,setDirection] = useState("all");
  const [layout,setLayout] = useState<"table"|"heatmap">("table");
  const [watched,setWatched] = useState<string[]>([]);
  const [watchReady,setWatchReady] = useState(false);
  useEffect(() => {
    try { const saved = window.localStorage.getItem("prominers_nexora_token_watchlist"); if (saved) setWatched(JSON.parse(saved)); } catch {}
    setWatchReady(true);
  }, []);
  useEffect(() => {
    if (!watchReady) return;
    try { window.localStorage.setItem("prominers_nexora_token_watchlist", JSON.stringify(watched)); } catch {}
  }, [watched,watchReady]);
  const filtered = useMemo(() => {
    const q=query.trim().toLowerCase();
    return [...tokens].filter(t => (!q || `${t.name} ${t.symbol} ${t.network} ${t.contractAddress ?? ""}`.toLowerCase().includes(q)) &&
      (network==="All networks" || t.network===network) &&
      (direction==="all" || (direction==="up" ? (t.market.priceChange24h??0)>=0 : (t.market.priceChange24h??0)<0)) &&
      (sort!=="name" || true)
    ).sort((a,b) => {
      if (sort === "name") {
        const cmp = a.name.localeCompare(b.name);
        return cmp * (ascending ? 1 : -1);
      }
      const av = a.market[sort] ?? 0;
      const bv = b.market[sort] ?? 0;
      return (av - bv) * (ascending ? 1 : -1);
    });
  },[query,network,sort,ascending,direction]);
  const totalCap=tokens.reduce((s,t)=>s+(t.market.marketCap??0),0);
  const totalVol=tokens.reduce((s,t)=>s+(t.market.volume24h??0),0);
  const avg=tokens.reduce((s,t)=>s+(t.market.priceChange24h??0),0)/Math.max(tokens.length,1);
  const gainers=[...tokens].sort((a,b)=>(b.market.priceChange24h??0)-(a.market.priceChange24h??0)).slice(0,3);
  const losers=[...tokens].sort((a,b)=>(a.market.priceChange24h??0)-(b.market.priceChange24h??0)).slice(0,3);
  const toggleWatch=(id:string)=>setWatched(v=>v.includes(id)?v.filter(x=>x!==id):[...v,id]);
  return <main className="nx-market">
    <header className="nx-market-head">
      <div><div className="nx-eyebrow"><span className="nx-live-dot"/> MARKET INTELLIGENCE <span className="nx-slash">/</span> DIGITAL ASSETS</div>
      <h1>Token <em>Markets</em></h1><p>Explore the market landscape, compare assets and follow on-chain ecosystems.</p></div>
      <div className="nx-head-meta"><span className="nx-data-pill"><i/> CATALOG SNAPSHOT</span><strong>{tokens.length.toString().padStart(2,"0")} <small>ASSETS TRACKED</small></strong></div>
    </header>
    <div className="nx-ticker">
      {tokens.slice(0,8).map(t=><Link href={`/tokens/${t.id}`} key={t.id} className="nx-ticker-item"><span className="nx-token-mark">{t.symbol.slice(0,1)}</span><b>{t.symbol}</b><span>{money(t.market.price)}</span><span className={(t.market.priceChange24h??0)>=0?"positive":"negative"}>{change(t.market.priceChange24h)}</span></Link>)}
    </div>
    <div className="nx-data-note"><span>●</span> Market data is illustrative catalogue data · Not a live trading feed <span className="nx-note-right">UPDATED {new Date().toLocaleDateString("en-US",{month:"short",day:"2-digit",year:"numeric"})}</span></div>
    <section className="nx-section">
      <div className="nx-section-title"><div><span className="nx-eyebrow">THE BIG PICTURE</span><h2>Market overview</h2></div><span className="nx-section-caption">AGGREGATED CATALOG METRICS</span></div>
      <div className="nx-overview-grid">
        <article className="nx-stat"><span>TRACKED MARKET CAP</span><strong>{money(totalCap)}</strong><small><BarChart3/> Across {tokens.length} listed assets</small></article>
        <article className="nx-stat"><span>24H TRADING VOLUME</span><strong>{money(totalVol)}</strong><small><Activity/> Aggregate reported volume</small></article>
        <article className="nx-stat"><span>AVERAGE 24H CHANGE</span><strong className={avg>=0?"positive":"negative"}>{change(avg)}</strong><small>{avg>=0?<TrendingUp/>:<TrendingDown/>} Mean token movement</small></article>
        <article className="nx-stat"><span>NETWORKS COVERED</span><strong>{networks.length-1}</strong><small><Globe2/> Ecosystems represented</small></article>
      </div>
    </section>
    <section className="nx-insight-grid">
      <article className="nx-panel"><div className="nx-panel-head"><div><span className="nx-eyebrow">24H PERFORMANCE</span><h3>Market movers</h3></div><span className="nx-mini-tag">TOP 3</span></div><div className="nx-mover-columns"><div><label className="positive">↗ TOP GAINERS</label>{gainers.map(t=><Link href={`/tokens/${t.id}`} className="nx-mover" key={t.id}><b>{t.symbol}</b><span>{t.name}</span><strong className="positive">{change(t.market.priceChange24h)}</strong></Link>)}</div><div><label className="negative">↘ TOP LOSERS</label>{losers.map(t=><Link href={`/tokens/${t.id}`} className="nx-mover" key={t.id}><b>{t.symbol}</b><span>{t.name}</span><strong className="negative">{change(t.market.priceChange24h)}</strong></Link>)}</div></div></article>
      <article className="nx-panel nx-distribution"><div className="nx-panel-head"><div><span className="nx-eyebrow">ECOSYSTEM MAP</span><h3>Market by network</h3></div></div>{networks.slice(1).map(n=>{const list=tokens.filter(t=>t.network===n);const cap=list.reduce((s,t)=>s+(t.market.marketCap??0),0);return <button key={n} onClick={()=>setNetwork(n)} className="nx-network-row"><span>{n}</span><div><i style={{width:`${Math.max(4,totalCap?cap/totalCap*100:4)}%`}}/></div><b>{money(cap)}</b></button>})}</article>
    </section>
    <section className="nx-section nx-directory">
      <div className="nx-section-title"><div><span className="nx-eyebrow">DISCOVER & COMPARE</span><h2>Token directory <sup>{filtered.length}</sup></h2></div><span className="nx-section-caption">RANKED BY MARKET CAPITALIZATION</span></div>
      <div className="nx-controls">
        <label className="nx-search"><Search/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search token, ticker or contract..."/>{query&&<button onClick={()=>setQuery("")}>×</button>}</label>
        <select value={network} onChange={e=>setNetwork(e.target.value)}>{networks.map(n=><option key={n}>{n}</option>)}</select>
        <select value={direction} onChange={e=>setDirection(e.target.value)}><option value="all">All movements</option><option value="up">Gainers</option><option value="down">Losers</option></select>
        <select value={sort} onChange={e=>{setSort(e.target.value as typeof sort);setAscending(false)}}><option value="marketCap">Market cap</option><option value="volume24h">Volume</option><option value="priceChange24h">24h change</option><option value="price">Price</option><option value="name">Name</option></select>
        <button className="nx-sort-toggle" onClick={()=>setAscending(!ascending)}><SlidersHorizontal/> {ascending?"Ascending":"Descending"}</button>
        <div className="nx-view-toggle"><button className={layout==="table"?"active":""} onClick={()=>setLayout("table")}>TABLE</button><button className={layout==="heatmap"?"active":""} onClick={()=>setLayout("heatmap")}>HEATMAP</button></div>
      </div>
      {layout==="table"?<div className="nx-table-wrap"><table className="nx-table"><thead><tr><th># / ASSET</th><th>PRICE</th><th>24H CHANGE</th><th>MARKET CAP</th><th>VOLUME (24H)</th><th>NETWORK</th><th/></tr></thead><tbody>{filtered.map((t,i)=><tr key={t.id}><td><Link href={`/tokens/${t.id}`} className="nx-asset"><span className="nx-token-mark">{t.symbol.slice(0,1)}</span><span><b>{t.name}</b><small>{t.symbol}</small></span></Link></td><td className="nx-number">{money(t.market.price)}</td><td><span className={`nx-change ${(t.market.priceChange24h??0)>=0?"positive":"negative"}`}>{change(t.market.priceChange24h)}</span></td><td className="nx-number">{money(t.market.marketCap)}</td><td className="nx-number">{money(t.market.volume24h)}</td><td><span className="nx-network-chip">{t.network}</span></td><td><button className={`nx-watch ${watched.includes(t.id)?"selected":""}`} onClick={()=>toggleWatch(t.id)} aria-label="Toggle watchlist"><Star/></button><Link className="nx-row-arrow" href={`/tokens/${t.id}`}><ArrowUpRight/></Link></td></tr>)}</tbody></table>{filtered.length===0&&<div className="nx-empty">No assets match these filters.</div>}</div>:<div className="nx-heatmap">{filtered.map(t=><Link href={`/tokens/${t.id}`} key={t.id} className={`nx-heat-tile ${(t.market.priceChange24h??0)>=0?"up":"down"}`} style={{flex:`${Math.max(1,t.market.marketCap??1)} 1 130px`}}><b>{t.symbol}</b><strong>{change(t.market.priceChange24h)}</strong><small>{money(t.market.marketCap)}</small></Link>)}</div>}
      <div className="nx-table-foot"><span>SHOWING {filtered.length} OF {tokens.length} ASSETS</span><span>VALUES IN USD · CATALOG SNAPSHOT</span></div>
    </section>
  </main>;
}

export function NexoraTokenDetail({ token }: { token: T }) {
  const [windowSize,setWindowSize]=useState<"12"|"20"|"28">("28");
  const [watched,setWatched]=useState(false);
  useEffect(() => {
    try { const saved = JSON.parse(window.localStorage.getItem("prominers_nexora_token_watchlist") || "[]"); setWatched(Array.isArray(saved) && saved.includes(token.id)); } catch {}
  }, [token.id]);
  const peers=tokens.filter(t=>t.network===token.network&&t.id!==token.id).sort((a,b)=>(b.market.marketCap??0)-(a.market.marketCap??0)).slice(0,5);
  const allCap=tokens.reduce((s,t)=>s+(t.market.marketCap??0),0);
  const capRank=[...tokens].sort((a,b)=>(b.market.marketCap??0)-(a.market.marketCap??0)).findIndex(t=>t.id===token.id)+1;
  const volRank=[...tokens].sort((a,b)=>(b.market.volume24h??0)-(a.market.volume24h??0)).findIndex(t=>t.id===token.id)+1;
  const price=token.market.price??0, cap=token.market.marketCap??0, vol=token.market.volume24h??0, ch=token.market.priceChange24h??0;
  const samples=Array.from({length:28},(_,i)=>price*(1+(Math.sin(i*1.17+token.id.length)*.026)+(Math.cos(i*.41+token.symbol.length)*.013)+(i/28-0.5)*(ch/150)));
  const series=samples.slice(-Number(windowSize)), min=Math.min(...series), max=Math.max(...series);
  const points=series.map((v,i)=>`${(i/(series.length-1))*100},${36-((v-min)/(max-min||1))*32}`).join(" ");
  const metrics=[["MARKET CAP",money(cap),`Rank ${capRank} of ${tokens.length}`],["24H VOLUME",money(vol),`Rank ${volRank} of ${tokens.length}`],["TURNOVER",`${cap?(vol/cap*100).toFixed(1):"0.0"}%`,"Volume ÷ market cap"],["BOOK SHARE",`${allCap?(cap/allCap*100).toFixed(2):"0.00"}%`,"Of tracked catalogue cap"]];
  return <main className="nx-market nx-token-detail">
    <div className="nx-detail-breadcrumb"><Link href="/tokens">TOKENS</Link><span>/</span><span>{token.symbol}</span></div>
    <header className="nx-token-hero"><div className="nx-token-identity"><div className="nx-token-emblem">{token.symbol.slice(0,1)}</div><div><div className="nx-eyebrow">{token.network.toUpperCase()} <span className="nx-slash">/</span> RANK #{capRank}</div><h1>{token.name} <em>({token.symbol})</em></h1><p>{token.description || "Digital asset listed in the ProMiners token catalogue."}</p></div></div><div className="nx-detail-price"><strong>{money(price)}</strong><span className={ch>=0?"positive":"negative"}>{change(ch)} <small>24H</small></span><button className={`nx-watch-large ${watched?"selected":""}`} onClick={()=>{const key="prominers_nexora_token_watchlist";let saved:string[]=[];try{saved=JSON.parse(window.localStorage.getItem(key)||"[]")}catch{}const next=watched?saved.filter(id=>id!==token.id):Array.from(new Set([...saved,token.id]));try{window.localStorage.setItem(key,JSON.stringify(next))}catch{}setWatched(!watched)}}><Star/> {watched?"WATCHING":"ADD TO WATCHLIST"}</button></div></header>
    <section className="nx-chart-panel"><div className="nx-chart-head"><div><span className="nx-eyebrow">PRICE PERFORMANCE</span><h2>{money(price)} <small className={ch>=0?"positive":"negative"}>{change(ch)}</small></h2></div><div className="nx-chart-period">{(["12","20","28"] as const).map(v=><button key={v} className={windowSize===v?"active":""} onClick={()=>setWindowSize(v)}>{v==="12"?"12H":v==="20"?"20D":"28D"}</button>)}</div></div><div className="nx-chart"><div className="nx-chart-grid"><span>{money(max)}</span><span>{money((max+min)/2)}</span><span>{money(min)}</span></div><svg viewBox="0 0 100 40" preserveAspectRatio="none"><defs><linearGradient id="nxPriceFill" x1="0" x2="0" y1="0" y2="1"><stop offset="0%" stopColor={ch>=0?"#70d8b1":"#fb7185"} stopOpacity=".28"/><stop offset="100%" stopColor={ch>=0?"#70d8b1":"#fb7185"} stopOpacity="0"/></linearGradient></defs><polygon points={`0,40 ${points} 100,40`} fill="url(#nxPriceFill)"/><polyline points={points} fill="none" stroke={ch>=0?"#70d8b1":"#fb7185"} strokeWidth=".65" vectorEffect="non-scaling-stroke"/></svg></div><div className="nx-chart-foot"><span>LOW <b>{money(min)}</b></span><span>ILLUSTRATIVE PRICE PATH · NOT HISTORICAL MARKET DATA</span><span>HIGH <b>{money(max)}</b></span></div></section>
    <section className="nx-detail-metrics">{metrics.map(([label,value,sub])=><article className="nx-stat" key={label}><span>{label}</span><strong>{value}</strong><small>{sub}</small></article>)}</section>
    <section className="nx-detail-columns"><div className="nx-panel"><div className="nx-panel-head"><div><span className="nx-eyebrow">ASSET INTELLIGENCE</span><h3>Asset profile</h3></div></div><p className="nx-profile-copy">{token.description || "No additional asset description has been provided."}</p><div className="nx-profile-list"><span>Network</span><b>{token.network}</b><span>Token standard</span><b>{token.standard || "—"}</b><span>Total supply</span><b>{token.totalSupply || "—"}</b><span>Decimals</span><b>{token.decimals ?? "—"}</b><span>Contract address</span><b className="nx-address">{token.contractAddress || "Not published"}</b><span>Verification</span><b>{(token.verificationStatus||"not_reviewed").replaceAll("_"," ")}</b></div><div className="nx-detail-actions"><Link href={`/tokens/${token.id}/contract`}>CONTRACT DETAILS ↗</Link><Link href={`/tokens/${token.id}/activity`}>TOKEN ACTIVITY ↗</Link></div></div><div className="nx-panel"><div className="nx-panel-head"><div><span className="nx-eyebrow">SAME ECOSYSTEM</span><h3>Network peers</h3></div><span className="nx-mini-tag">{peers.length} ASSETS</span></div>{peers.length?peers.map(p=><Link href={`/tokens/${p.id}`} className="nx-peer" key={p.id}><span className="nx-token-mark">{p.symbol.slice(0,1)}</span><span><b>{p.name}</b><small>{p.symbol}</small></span><strong>{money(p.market.price)}</strong><em className={(p.market.priceChange24h??0)>=0?"positive":"negative"}>{change(p.market.priceChange24h)}</em></Link>):<p className="nx-profile-copy">No other assets are listed on this network.</p>}<Link className="nx-all-peers" href="/tokens">EXPLORE ALL TOKENS ↗</Link></div></section>
    <div className="nx-detail-nav"><Link href="/tokens">← BACK TO TOKEN DIRECTORY</Link><span>CATALOG DATA · NOT A LIVE TRADING TERMINAL</span></div>
  </main>;
}
