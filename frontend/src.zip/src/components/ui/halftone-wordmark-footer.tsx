// Halftone Wordmark Footer - a site footer whose wordmark is set enormous and
// cropped by the bottom edge, printed as a field of halftone dots. Each dot is
// sized by how much of the letter covers its cell, so the type keeps its edges
// at any scale. Move across it and the dots part around the pointer on springs,
// warming in colour as they are pushed off their place; click and a shock ring
// runs through the word. Above it sit the studio line and link columns; a
// floating circular back-to-top control appears after the page is scrolled.

import * as React from "react";
import { Link } from "react-router-dom";
import { ArrowUp } from "lucide-react";

export interface HalftonePalette {
  /** The footer background. */
  background: string;
  /** The dots at rest, and the text. */
  ink: string;
  /** The colour a dot warms toward as it is pushed off its place. */
  warm: string;
}

export type HalftonePreset = "night" | "paper" | "ember" | "cobalt";

export interface FooterLink {
  label: string;
  href?: string;
}

export interface FooterColumn {
  title: string;
  links: FooterLink[];
}

export interface HalftoneWordmarkFooterProps {
  /** The giant word printed in dots. Lowercase reads best. */
  wordmark?: string;
  /** Top-left studio line. */
  label?: string;
  /** The muted line under it. */
  meta?: string;
  /** Link columns along the top. */
  columns?: FooterColumn[];
  /** Starting colours. Defaults to "night". */
  preset?: HalftonePreset;
  /** Colour overrides, merged over the preset. */
  palette?: { background?: string; ink?: string; warm?: string };
  /** Distance between dot centres, in CSS px. Defaults to 6. */
  dotGap?: number;
  /** How far the pointer pushes, in CSS px. Defaults to 80. */
  radius?: number;
  /** How much of the word's cap height hangs below the bottom edge, 0-0.6. Defaults to 0.2. */
  crop?: number;
  /** Print grain over everything, 0-1. Defaults to 0.5. */
  grain?: number;
  /** Pointer and click response. Defaults to true. */
  interactive?: boolean;
  /** Face for the wordmark. Heavy grotesks print best. */
  fontFamily?: string;
  /** Weight of the wordmark. Defaults to 800. */
  fontWeight?: number;
  /** Face for the small type. */
  monoFamily?: string;
  /** Root height. A definite length, never a percentage. */
  height?: string;
  /** Extra root class names. */
  className?: string;
}

const PRESETS: { [K in HalftonePreset]: HalftonePalette } = {
  night: { background: "#0C0C0B", ink: "#E9E4DA", warm: "#E9762B" },
  paper: { background: "#efebe3", ink: "#17150f", warm: "#c2361c" },
  ember: { background: "#160a06", ink: "#f2c48c", warm: "#ff5a1f" },
  cobalt: { background: "#0d1b4d", ink: "#dfe7ff", warm: "#ffcd3c" },
};

const DEFAULT_COLUMNS: FooterColumn[] = [
  {
    title: "Explore",
    links: [
      { label: "Ecosystem", href: "/explore" },
      { label: "Tokens", href: "/tokens" },
      { label: "Launchpad", href: "/launchpad" },
      { label: "Airdrops", href: "/airdrops" },
      { label: "Staking", href: "/staking" },
    ],
  },
  {
    title: "Protocol",
    links: [
      { label: "Documentation", href: "/docs" },
      { label: "Guides & FAQ", href: "/docs/guides" },
      { label: "Risk Notice", href: "/docs/risk" },
      { label: "Terms of Service", href: "/docs/terms" },
      { label: "Privacy Policy", href: "/docs/privacy" },
    ],
  },
  {
    title: "Connect",
    links: [
      { label: "X / Twitter", href: "https://x.com/prominers" },
      { label: "Discord", href: "https://discord.gg/prominers" },
      { label: "GitHub", href: "https://github.com/prominers" },
      { label: "Contact Us", href: "mailto:hello@prominers.io" },
    ],
  },
];

const SANS_STACK = '"Outfit", "Helvetica Neue", Arial, system-ui, sans-serif';
const MONO_STACK = '"IBM Plex Mono", ui-monospace, SFMono-Regular, Menlo, Consolas, monospace';

/** Hex -> [r, g, b] in 0-255, or null for anything that isn't #rgb / #rrggbb. */
export function hwfHex(hex: string): [number, number, number] | null {
  const m = /^#?([0-9a-f]{3}|[0-9a-f]{6})$/i.exec((hex || "").trim());
  if (!m) return null;
  const h =
    m[1].length === 3
      ? m[1]
          .split("")
          .map((c) => c + c)
          .join("")
      : m[1];
  return [
    parseInt(h.slice(0, 2), 16),
    parseInt(h.slice(2, 4), 16),
    parseInt(h.slice(4, 6), 16),
  ];
}

/** Parses hex or rgb/rgba color string to [r, g, b] tuple. */
export function hwfColorToRgb(color: string): [number, number, number] | null {
  if (!color) return null;
  const c = color.trim();
  const hex = hwfHex(c);
  if (hex) return hex;
  const m = /^rgba?\((\d+)\s*,\s*(\d+)\s*,\s*(\d+)/i.exec(c);
  if (m) {
    return [parseInt(m[1], 10), parseInt(m[2], 10), parseInt(m[3], 10)];
  }
  return null;
}

/** Dot radius for a cell coverage in [0, 1]: area-true, so tone stays even. */
export function hwfRadius(coverage: number, gap: number): number {
  const c = coverage < 0 ? 0 : coverage > 1 ? 1 : coverage;
  return Math.sqrt(c) * gap * 0.56;
}

/**
 * One step of a dot's spring back to home, plus the push from a pointer at
 * (px, py) within radius r. Returns [x, y, vx, vy].
 */
export function hwfStep(
  x: number,
  y: number,
  vx: number,
  vy: number,
  hx: number,
  hy: number,
  px: number,
  py: number,
  r: number
): [number, number, number, number] {
  const dx = x - px;
  const dy = y - py;
  const d2 = dx * dx + dy * dy;
  if (r > 0 && d2 < r * r) {
    const d = Math.sqrt(d2) + 0.001;
    const f = (1 - d / r) * 2.6;
    vx += (dx / d) * f;
    vy += (dy / d) * f;
  }
  vx = (vx + (hx - x) * 0.05) * 0.84;
  vy = (vy + (hy - y) * 0.05) * 0.84;
  return [x + vx, y + vy, vx, vy];
}

/** How warm a dot is drawn: 0 at home, 1 once it is `span` px or more away. */
export function hwfWarmth(
  x: number,
  y: number,
  hx: number,
  hy: number,
  span: number
): number {
  const d = Math.hypot(x - hx, y - hy);
  return span > 0 ? Math.min(1, d / span) : 0;
}

/** Font size that sets `measured` (width at 100px) to fill `width` exactly. */
export function hwfFitSize(measured: number, width: number): number {
  return measured > 0 ? (width / measured) * 100 : 0;
}

const HWF_CSS = `
.hwf-root {
  position: relative; width: 100%; overflow: hidden; isolation: isolate;
  background-color: var(--hwf-bg, var(--footer-bg, var(--page-bg, var(--background)))) !important;
  background-image: none !important;
  color: var(--hwf-ink, var(--footer-text, var(--text-primary, var(--foreground))));
  border-top: 1px solid var(--footer-divider, var(--border-subtle, var(--border)));
  transition: background-color 420ms ease, color 420ms ease, border-color 420ms ease;
  -webkit-font-smoothing: antialiased;
}
.hwf-top {
  position: relative; z-index: 1; display: grid; grid-template-columns: minmax(0, 1.25fr) repeat(3, minmax(0, 1fr));
  gap: 24px; padding: clamp(22px, 3.4vw, 40px) clamp(20px, 3.4vw, 44px) 0;
  font-family: var(--font-sans, var(--font-outfit)); font-size: 12px; letter-spacing: .015em; text-transform: none; line-height: 1.8;
}
.hwf-brand strong { display: block; font-family: var(--font-sans, var(--font-outfit)); font-size: 12px; font-weight: 700; letter-spacing: .12em; color: var(--hwf-ink, var(--footer-text, currentColor)); }
.hwf-brand span { display: block; margin-top: 3px; opacity: .62; font: 9px/1.6 var(--hwf-mono); letter-spacing: .08em; color: var(--footer-text-muted, inherit); }
.hwf-col h3 { margin: 0 0 3px; font: 600 9px/1.6 var(--hwf-mono); letter-spacing: .12em; text-transform: uppercase; opacity: .68; color: var(--footer-text-muted, var(--hwf-ink, currentColor)); }
.hwf-col ul { list-style: none; margin: 0; padding: 0; }
.hwf-col a {
  color: var(--hwf-ink, var(--footer-text, currentColor)); text-decoration: none; opacity: .82; background: none; border: 0; padding: 0;
  font: inherit; letter-spacing: inherit; text-transform: inherit; cursor: pointer;
  background-image: linear-gradient(currentColor, currentColor); background-size: 0% 1px;
  background-repeat: no-repeat; background-position: 0 100%; transition: opacity .25s ease, background-size .35s cubic-bezier(.2,.7,.1,1), color .25s ease;
}
.hwf-col a:hover { opacity: 1; background-size: 100% 1px; color: var(--hwf-warm, var(--footer-warm, var(--primary))); }
.hwf-col a:focus-visible { outline: 1px solid var(--hwf-warm, var(--footer-warm, var(--primary))); outline-offset: 3px; opacity: 1; }
.hwf-floating-up {
  position: fixed; right: 26px; bottom: 26px; z-index: 1200;
  display: grid; place-items: center; width: 68px; height: 68px;
  border: 1px solid rgba(17, 24, 39, .12); border-radius: 9999px;
  background: #E7E9EE; color: #111827;
  box-shadow: 0 8px 28px rgba(0, 0, 0, .24);
  cursor: pointer; opacity: 1; transform: translateY(0);
  transition: opacity 180ms ease, transform 180ms ease, background-color 180ms ease;
}
.hwf-floating-up:hover { background: #FFFFFF; transform: translateY(-3px); }
.hwf-floating-up:focus-visible { outline: 2px solid var(--primary); outline-offset: 4px; }
.hwf-floating-up svg { width: 29px; height: 29px; stroke-width: 2.6; }
.hwf-floating-up[hidden] { display: none; }
@media (max-width: 640px) {
  .hwf-floating-up { right: 17px; bottom: 18px; width: 56px; height: 56px; }
  .hwf-floating-up svg { width: 25px; height: 25px; }
}
@media (prefers-reduced-motion: reduce) {
  .hwf-floating-up { transition: none; }
}
.hwf-sr { position: absolute; width: 1px; height: 1px; overflow: hidden; clip-path: inset(50%); white-space: nowrap; }
@media (max-width: 720px) {
  .hwf-root.route-themed-footer { height: auto !important; min-height: 300px; }
  .hwf-top { grid-template-columns: minmax(0, 1fr) minmax(0, 1fr); row-gap: 18px; }
  .hwf-brand { grid-column: 1 / -1; }
}
@media (prefers-reduced-motion: reduce) {
  .hwf-col a { transition: none; }
}
`;

type PointerEv = PointerEvent;

export default function HalftoneWordmarkFooter({
  wordmark = "Horizon X",
  label = "HORIZONX",
  meta = "© 2026 • BUILDING THE OPEN WEB",
  columns = DEFAULT_COLUMNS,
  preset = "night",
  palette,
  dotGap = 6,
  radius = 95,
  crop = 0.19,
  grain = 0.35,
  interactive = true,
  fontFamily = SANS_STACK,
  fontWeight = 800,
  monoFamily = MONO_STACK,
  height = "490px",
  className = "",
}: HalftoneWordmarkFooterProps) {
  const colors = { ...(PRESETS[preset] || PRESETS.night), ...(palette || {}) };
  const [showBackToTop, setShowBackToTop] = React.useState(false);
  const rootRef = React.useRef<HTMLElement | null>(null);
  const canvasRef = React.useRef<HTMLCanvasElement | null>(null);
  const opts = React.useRef({
    colors,
    dotGap,
    radius,
    crop,
    grain,
    interactive,
    fontFamily,
    fontWeight,
    wordmark,
  });
  const key = [
    wordmark,
    dotGap,
    crop,
    grain,
    fontFamily,
    fontWeight,
    colors.background,
    colors.ink,
    colors.warm,
  ].join("|");

  React.useEffect(() => {
    const updateVisibility = () => setShowBackToTop(window.scrollY > 320);
    updateVisibility();
    window.addEventListener("scroll", updateVisibility, { passive: true });
    return () => window.removeEventListener("scroll", updateVisibility);
  }, []);

  React.useEffect(() => {
    opts.current = {
      colors,
      dotGap,
      radius,
      crop,
      grain,
      interactive,
      fontFamily,
      fontWeight,
      wordmark,
    };
    const root = rootRef.current;
    const canvas = canvasRef.current;
    if (!root || !canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const reduced = window.matchMedia(
      "(prefers-reduced-motion: reduce)"
    ).matches;
    let w = 0;
    let h = 0;
    let dpr = 1;
    let px = -1e5;
    let py = -1e5;
    let raf = 0;
    let visible = true;
    let awake = true;
    let ring = { x: 0, y: 0, t: -1 };
    // Flat arrays: x, y, vx, vy, hx, hy, r per dot.
    let dots = new Float32Array(0);
    let count = 0;
    let grainTile: HTMLCanvasElement | null = null;
    let ink = hwfColorToRgb(opts.current.colors.ink) || [233, 228, 218];
    let warm = hwfColorToRgb(opts.current.colors.warm) || [169, 154, 255];
    let activeInk: string = opts.current.colors.ink;

    const layout = () => {
      const o = opts.current;
      const comp = window.getComputedStyle(root);
      const cssInk = (palette?.ink || comp.getPropertyValue("--footer-text").trim() || comp.getPropertyValue("--hwf-ink").trim() || o.colors.ink).trim();
      const cssWarm = (palette?.warm || comp.getPropertyValue("--footer-warm").trim() || comp.getPropertyValue("--hwf-warm").trim() || o.colors.warm).trim();
      ink = hwfColorToRgb(cssInk) || [233, 228, 218];
      warm = hwfColorToRgb(cssWarm) || [169, 154, 255];
      activeInk = cssInk;

      const rect = root.getBoundingClientRect();
      w = Math.max(1, Math.round(rect.width));
      h = Math.max(1, Math.round(rect.height));
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      canvas.width = Math.round(w * dpr);
      canvas.height = Math.round(h * dpr);

      // Set the word once, at a size that fills the width, on a 1x mask.
      const mask = document.createElement("canvas");
      mask.width = w;
      mask.height = h;
      const m = mask.getContext("2d", { willReadFrequently: true });
      if (!m) return;
      const face = o.fontWeight + " 100px " + o.fontFamily;
      m.font = face;
      const word = o.wordmark || " ";
      const fit = hwfFitSize(m.measureText(word).width, w * 1.02);
      m.font = o.fontWeight + " " + fit + "px " + o.fontFamily;
      const box = m.measureText(word);
      m.fillStyle = "#000";
      m.textBaseline = "alphabetic";
      m.fillText(word, (w - box.width) / 2, h - 28);
      const img = m.getImageData(0, 0, w, h).data;

      const gap = Math.max(3, o.dotGap);
      const cols = Math.ceil(w / gap);
      const rows = Math.ceil(h / gap);
      const tmp: number[] = [];
      for (let gy = 0; gy < rows; gy++) {
        for (let gx = 0; gx < cols; gx++) {
          // Coverage: average alpha over a 3x3 sample of the cell.
          let sum = 0;
          for (let sy = 0; sy < 3; sy++) {
            for (let sx = 0; sx < 3; sx++) {
              const x = Math.min(
                w - 1,
                Math.floor(gx * gap + ((sx + 0.5) * gap) / 3)
              );
              const y = Math.min(
                h - 1,
                Math.floor(gy * gap + ((sy + 0.5) * gap) / 3)
              );
              sum += img[(y * w + x) * 4 + 3];
            }
          }
          const cov = sum / (9 * 255);
          if (cov < 0.06) continue;
          const hx = gx * gap + gap / 2;
          const hy = gy * gap + gap / 2;
          tmp.push(hx, hy, 0, 0, hx, hy, hwfRadius(cov, gap));
        }
      }
      dots = new Float32Array(tmp);
      count = tmp.length / 7;

      // A fixed tile of print grain, drawn once and laid over every frame.
      grainTile = document.createElement("canvas");
      grainTile.width = 256;
      grainTile.height = 256;
      const g = grainTile.getContext("2d");
      if (g) {
        const id = g.createImageData(256, 256);
        for (let i = 0; i < id.data.length; i += 4) {
          const v = Math.random() * 255;
          id.data[i] = id.data[i + 1] = id.data[i + 2] = v;
          id.data[i + 3] = Math.random() < 0.5 ? 0 : 255;
        }
        g.putImageData(id, 0, 0);
      }
      awake = true;
    };

    const draw = (now: number) => {
      const o = opts.current;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, w, h);

      const r = o.interactive && !reduced ? Math.max(0, o.radius) : 0;
      const ringAge = ring.t < 0 ? 1e9 : now - ring.t;
      const ringR = ringAge * 0.9;
      let moving = false;
      for (let i = 0; i < count; i++) {
        const j = i * 7;
        let x = dots[j];
        let y = dots[j + 1];
        let vx = dots[j + 2];
        let vy = dots[j + 3];
        const hx = dots[j + 4];
        const hy = dots[j + 5];
        if (!reduced) {
          if (ringAge < 900) {
            const dx = hx - ring.x;
            const dy = hy - ring.y;
            const d = Math.sqrt(dx * dx + dy * dy) + 0.001;
            const band = 1 - Math.min(1, Math.abs(d - ringR) / 26);
            if (band > 0) {
              const f = band * 3.2 * (1 - ringAge / 900);
              vx += (dx / d) * f;
              vy += (dy / d) * f;
            }
          }
          const s = hwfStep(x, y, vx, vy, hx, hy, px, py, r);
          x = s[0];
          y = s[1];
          vx = s[2];
          vy = s[3];
          if (
            Math.abs(vx) + Math.abs(vy) > 0.02 ||
            Math.abs(x - hx) + Math.abs(y - hy) > 0.05
          )
            moving = true;
          else {
            x = hx;
            y = hy;
            vx = 0;
            vy = 0;
          }
          dots[j] = x;
          dots[j + 1] = y;
          dots[j + 2] = vx;
          dots[j + 3] = vy;
        }
        const k = hwfWarmth(x, y, hx, hy, 28);
        ctx.fillStyle =
          k > 0.02
            ? "rgb(" +
              Math.round(ink[0] + (warm[0] - ink[0]) * k) +
              "," +
              Math.round(ink[1] + (warm[1] - ink[1]) * k) +
              "," +
              Math.round(ink[2] + (warm[2] - ink[2]) * k) +
              ")"
            : activeInk;
        ctx.beginPath();
        ctx.arc(x, y, dots[j + 6], 0, 6.2832);
        ctx.fill();
      }

      if (grainTile && o.grain > 0) {
        ctx.globalAlpha = Math.min(1, o.grain) * 0.09;
        ctx.globalCompositeOperation = "overlay";
        const pattern = ctx.createPattern(grainTile, "repeat");
        if (pattern) {
          ctx.fillStyle = pattern;
          ctx.fillRect(0, 0, w, h);
        }
        ctx.globalAlpha = 1;
        ctx.globalCompositeOperation = "source-over";
      }
      // Sleep once everything is home and nothing is pushing.
      awake = moving || ringAge < 900 || px > -1e4;
    };

    const loop = (now: number) => {
      raf = 0;
      if (!visible) return;
      draw(now);
      if (awake) raf = requestAnimationFrame(loop);
    };
    const wake = () => {
      awake = true;
      if (!raf && visible) raf = requestAnimationFrame(loop);
    };

    const toLocal = (e: PointerEv): [number, number] => {
      const b = canvas.getBoundingClientRect();
      return [e.clientX - b.left, e.clientY - b.top];
    };
    const onMove = (e: PointerEv) => {
      if (!opts.current.interactive) return;
      const p = toLocal(e);
      px = p[0];
      py = p[1];
      wake();
    };
    const onLeave = () => {
      px = -1e5;
      py = -1e5;
      wake();
    };
    const onDown = (e: PointerEv) => {
      if (!opts.current.interactive || reduced) return;
      if ((e.target as HTMLElement).closest("a,button")) return;
      const p = toLocal(e);
      ring = { x: p[0], y: p[1], t: performance.now() };
      wake();
    };

    layout();
    draw(performance.now());
    wake();

    root.addEventListener("pointermove", onMove);
    root.addEventListener("pointerleave", onLeave);
    root.addEventListener("pointerdown", onDown);
    const ro = new ResizeObserver(() => {
      layout();
      wake();
    });
    ro.observe(root);
    const io = new IntersectionObserver((entries) => {
      visible = entries[0] ? entries[0].isIntersecting : true;
      if (visible) wake();
    });
    io.observe(root);

    const themeTarget = root.closest("[data-theme]") || document.documentElement;
    const mo = new MutationObserver(() => {
      layout();
      wake();
    });
    mo.observe(themeTarget, { attributes: true, attributeFilter: ["data-theme", "class"] });

    let alive = true;
    if (document.fonts && document.fonts.ready) {
      document.fonts.ready.then(() => {
        if (!alive) return;
        layout();
        wake();
      });
    }

    return () => {
      alive = false;
      cancelAnimationFrame(raf);
      ro.disconnect();
      io.disconnect();
      mo.disconnect();
      root.removeEventListener("pointermove", onMove);
      root.removeEventListener("pointerleave", onLeave);
      root.removeEventListener("pointerdown", onDown);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key]);

  const toTop = () => {
    // Explore pages can be hosted by either the document scroller or a route
    // wrapper. Reset the known page-level scroll roots instead of assuming
    // window is the only scrolling element.
    const candidates: (HTMLElement | null)[] = [
      document.scrollingElement as HTMLElement | null,
      document.documentElement,
      document.body,
      document.getElementById("root"),
      document.querySelector(".route-shell"),
      document.querySelector(".route-main"),
      document.querySelector(".route-page-transition"),
      document.querySelector(".explore-page"),
      document.querySelector(".explore-hero")?.parentElement ?? null,
    ];

    const unique = Array.from(new Set(candidates.filter(Boolean))) as HTMLElement[];
    unique.forEach((element) => {
      element.scrollTo({ top: 0, left: 0, behavior: "smooth" });
      // Explicitly reset scrollTop as a fallback for wrappers that don't
      // expose a reliable scrollTo implementation.
      element.scrollTop = 0;
    });

    window.scrollTo({ top: 0, left: 0, behavior: "smooth" });
  };

  return (
    <footer
      ref={rootRef}
      className={"hwf-root " + className}
      style={
        {
          height,
          ...(palette?.background ? { "--hwf-bg": palette.background } : {}),
          ...(palette?.ink ? { "--hwf-ink": palette.ink } : {}),
          ...(palette?.warm ? { "--hwf-warm": palette.warm } : {}),
          "--hwf-mono": monoFamily,
        } as React.CSSProperties
      }
    >
      <style>{HWF_CSS}</style>
      <div className="hwf-top">
        <div className="hwf-brand">
          <strong>{label}</strong>
          <span>{meta}</span>
        </div>
        {columns.map((col) => (
          <nav className="hwf-col" key={col.title} aria-label={col.title}>
            <h3>{col.title}</h3>
            <ul>
              {col.links.map((l) => (
                <li key={l.label}>
                  {l.href?.startsWith("/") ? (
                    <Link to={l.href}>{l.label}</Link>
                  ) : (
                    <a
                      href={l.href || "#"}
                      target={l.href?.startsWith("http") ? "_blank" : undefined}
                      rel={
                        l.href?.startsWith("http")
                          ? "noopener noreferrer"
                          : undefined
                      }
                    >
                      {l.label}
                    </a>
                  )}
                </li>
              ))}
            </ul>
          </nav>
        ))}
      </div>
      <button
        type="button"
        className="hwf-floating-up"
        onClick={toTop}
        aria-label="Back to top"
        title="Back to top"
        hidden={!showBackToTop}
      >
        <ArrowUp aria-hidden="true" />
      </button>
    </footer>
  );
}
