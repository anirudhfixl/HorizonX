import React from "react";
import { cn } from "@/lib/utils";
import { Link } from "react-router-dom";
import { motion, type MotionValue } from "motion/react";
import {
  Database, Rocket, Gift, Layers, Network, Box, Share2, Handshake, Users,
} from "lucide-react";

const transition = {
  duration: 0,
  ease: "linear" as const,
};

type GoogleGeminiEffectProps = {
  pathLengths: MotionValue<number>[];
  title?: string;
  description?: string;
  className?: string;
};

const paths = [
  {
    d: "M0 663C145.5 663 191 666.265 269 647C326.5 630 339.5 621 397.5 566C439 531.5 455 529.5 490 523C509.664 519.348 521 503.736 538 504.236C553.591 504.236 562.429 514.739 584.66 522.749C592.042 525.408 600.2 526.237 607.356 523.019C624.755 515.195 641.446 496.324 657 496.735C673.408 496.735 693.545 519.572 712.903 526.769C718.727 528.934 725.184 528.395 730.902 525.965C751.726 517.115 764.085 497.106 782 496.735C794.831 496.47 804.103 508.859 822.469 518.515C835.13 525.171 850.214 526.815 862.827 520.069C875.952 513.049 889.748 502.706 903.5 503.736C922.677 505.171 935.293 510.562 945.817 515.673C954.234 519.76 963.095 522.792 972.199 524.954C996.012 530.611 1007.42 534.118 1034 549C1077.5 573.359 1082.5 594.5 1140 629C1206 670 1328.5 662.5 1440 662.5",
    color: "#F0A6C4",
  },
  {
    d: "M0 587.5C147 587.5 277 587.5 310 573.5C348 563 392.5 543.5 408 535C434 523.5 426 526.235 479 515.235C494 512.729 523 510.435 534.5 512.735C554.5 516.735 555.5 523.235 576 523.735C592 523.735 616 496.735 633 497.235C648.671 497.235 661.31 515.052 684.774 524.942C692.004 527.989 700.2 528.738 707.349 525.505C724.886 517.575 741.932 498.33 757.5 498.742C773.864 498.742 791.711 520.623 810.403 527.654C816.218 529.841 822.661 529.246 828.451 526.991C849.246 518.893 861.599 502.112 879.5 501.742C886.47 501.597 896.865 506.047 907.429 510.911C930.879 521.707 957.139 519.639 982.951 520.063C1020.91 520.686 1037.5 530.797 1056.5 537C1102.24 556.627 1116.5 570.704 1180.5 579.235C1257.5 589.5 1279 587 1440 588",
    color: "#E6C9A8",
  },
  {
    d: "M0 514C147.5 514.333 294.5 513.735 380.5 513.735C405.976 514.94 422.849 515.228 436.37 515.123C477.503 514.803 518.631 506.605 559.508 511.197C564.04 511.706 569.162 512.524 575 513.735C588 516.433 616 521.702 627.5 519.402C647.5 515.402 659 499.235 680.5 499.235C700.5 499.235 725 529.235 742 528.735C757.654 528.735 768.77 510.583 791.793 500.59C798.991 497.465 807.16 496.777 814.423 499.745C832.335 507.064 850.418 524.648 866 524.235C882.791 524.235 902.316 509.786 921.814 505.392C926.856 504.255 932.097 504.674 937.176 505.631C966.993 511.248 970.679 514.346 989.5 514.735C1006.3 515.083 1036.5 513.235 1055.5 513.235C1114.5 513.235 1090.5 513.235 1124 513.235C1177.5 513.235 1178.99 514.402 1241 514.402C1317.5 514.402 1274.5 512.568 1440 513.235",
    color: "#B8C8FF",
  },
  {
    d: "M0 438.5C150.5 438.5 261 438.318 323.5 456.5C351 464.5 387.517 484.001 423.5 494.5C447.371 501.465 472 503.735 487 507.735C503.786 512.212 504.5 516.808 523 518.735C547 521.235 564.814 501.235 584.5 501.235C604.5 501.235 626 529.069 643 528.569C658.676 528.569 672.076 511.63 695.751 501.972C703.017 499.008 711.231 498.208 718.298 501.617C735.448 509.889 751.454 529.98 767 529.569C783.364 529.569 801.211 507.687 819.903 500.657C825.718 498.469 832.141 499.104 837.992 501.194C859.178 508.764 873.089 523.365 891 523.735C907.8 524.083 923 504.235 963 506.735C1034.5 506.735 1047.5 492.68 1071 481.5C1122.5 457 1142.23 452.871 1185 446.5C1255.5 436 1294 439 1439.5 439",
    color: "#65B7FF",
  },
  {
    d: "M0.5 364C145.288 362.349 195 361.5 265.5 378C322 391.223 399.182 457.5 411 467.5C424.176 478.649 456.916 491.677 496.259 502.699C498.746 503.396 501.16 504.304 503.511 505.374C517.104 511.558 541.149 520.911 551.5 521.236C571.5 521.236 590 498.736 611.5 498.736C631.5 498.736 652.5 529.236 669.5 528.736C685.171 528.736 697.81 510.924 721.274 501.036C728.505 497.988 736.716 497.231 743.812 500.579C761.362 508.857 778.421 529.148 794 528.736C810.375 528.736 829.35 508.68 848.364 502.179C854.243 500.169 860.624 500.802 866.535 502.718C886.961 509.338 898.141 519.866 916 520.236C932.8 520.583 934.5 510.236 967.5 501.736C1011.5 491 1007.5 493.5 1029.5 480C1069.5 453.5 1072 440.442 1128.5 403.5C1180.5 369.5 1275 360.374 1439 364",
    color: "#287BFF",
  },
] as const;

const featureColors = ["#287BFF", "#65DDF7", "#A78BFA", "#F4CF83", "#F06FBE"] as const;

function FeatureRow({
  label,
  icon: Icon,
  color,
  side,
  href,
  external = false,
}: {
  label: string;
  icon: React.ElementType;
  color: string;
  side: "left" | "right";
  href: string;
  external?: boolean;
}) {
  const rowStyle: React.CSSProperties = {
    display: "flex",
    minWidth: 0,
    width: "100%",
    alignItems: "center",
    transform: label === "Markets" || label === "Community" ? "translateY(-8px)" : undefined,
    justifyContent: side === "right" ? "flex-end" : "flex-start",
    gap: "14px",
    color: "#f5f6ff",
    fontFamily: "inherit",
  };
  const iconStyle: React.CSSProperties = {
    position: "relative",
    zIndex: 2,
    display: "grid",
    width: "42px",
    height: "42px",
    flex: "0 0 42px",
    placeItems: "center",
    color,
    border: `1px solid ${color}`,
    borderRadius: "12px",
    background: "rgba(7, 10, 24, .88)",
    boxShadow: `0 0 16px ${color}22, inset 0 0 12px ${color}0d`,
  };
  const labelStyle: React.CSSProperties = {
    position: "relative",
    zIndex: 2,
    minWidth: 0,
    color: "#f4f5fc",
    fontSize: "14px",
    fontWeight: 650,
    lineHeight: 1.2,
    whiteSpace: "nowrap",
    textAlign: side === "right" ? "right" : "left",
    padding: "4px 9px",
    borderRadius: "5px",
    background: "rgba(7, 10, 24, .92)",
    textShadow: "0 1px 5px rgba(0,0,0,.7)",
  };

  const linkStyle: React.CSSProperties = {
    ...rowStyle,
    textDecoration: "none",
    cursor: "pointer",
    outlineOffset: "5px",
    transition: "filter 180ms ease, transform 180ms ease",
  };
  const content = (
    <>
      {side === "left" ? (
        <>
          <span className="hx-gemini-feature-icon" style={iconStyle}><Icon aria-hidden="true" size={22} strokeWidth={1.9} /></span>
          <strong className="hx-gemini-feature-label" style={labelStyle}>{label}</strong>
        </>
      ) : (
        <>
          <strong className="hx-gemini-feature-label" style={labelStyle}>{label}</strong>
          <span className="hx-gemini-feature-icon" style={iconStyle}><Icon aria-hidden="true" size={22} strokeWidth={1.9} /></span>
        </>
      )}
    </>
  );

  const className = `hx-gemini-feature-row hx-gemini-feature-row--${side}`;
  return external ? (
    <a className={className} href={href} target="_blank" rel="noopener noreferrer" aria-label={`Open ${label}`} style={linkStyle}>
      {content}
    </a>
  ) : (
    <Link className={className} to={href} aria-label={`Go to ${label}`} style={linkStyle}>
      {content}
    </Link>
  );
}

const leftFeatures = [
  { label: "Tokens", icon: Database, path: 4, href: "/tokens" },
  { label: "Launchpad", icon: Rocket, path: 3, href: "/launchpad" },
  { label: "Airdrops", icon: Gift, path: 2, href: "/airdrops" },
  { label: "Staking", icon: Layers, path: 1, href: "/staking" },
  { label: "Markets", icon: Network, path: 0, href: "/tokens/explore" },
] as const;

const rightFeatures = [
  { label: "Projects", icon: Box, path: 4, href: "/projects" },
  { label: "Protocols", icon: Layers, path: 3, href: "/explore/projects" },
  { label: "Ecosystems", icon: Share2, path: 2, href: "/explore" },
  { label: "Partners", icon: Handshake, path: 1, href: "/partners" },
  { label: "Community", icon: Users, path: 0, href: "https://discord.gg/prominers", external: true },
] as const;

export function GoogleGeminiEffect({
  pathLengths,
  title = "Build with HorizonX",
  description = "A connected Web3 ecosystem. Scroll to see how the pieces come together.",
  className,
}: GoogleGeminiEffectProps) {
  return (
    <div className={cn("hx-gemini-effect sticky top-24 relative mx-auto w-full translate-y-4 sm:translate-y-6", className)}>
      <div className="relative z-10 px-5 pt-8 text-center sm:pt-12">
        <p
          className="bg-gradient-to-b from-white via-white to-violet-200 bg-clip-text pb-3 font-semibold tracking-[-.055em] text-transparent"
          style={{ fontSize: "clamp(2.75rem, 5vw, 4.5rem)", lineHeight: 1.08 }}
        >
          {title}
        </p>
        <p className="mx-auto mt-3 max-w-2xl text-sm leading-7 text-violet-100/60 sm:text-base md:text-lg">
          {description}
        </p>
      </div>

      <div
        className="hx-gemini-feature-rail--left"
        aria-label="HorizonX platform features"
        style={{
          position: "absolute",
          zIndex: 12,
          top: "calc(5.8rem + 4.45vw)",
          left: "clamp(1.5rem, 4.1vw, 4.5rem)",
          display: "grid",
          gap: "calc(5.17vw - 42px)",
          width: "clamp(230px, 20.5vw, 300px)",
        }}
      >
        {leftFeatures.map((feature) => (
          <FeatureRow
            key={feature.label}
            label={feature.label}
            icon={feature.icon}
            color={featureColors[4 - feature.path]}
            side="left"
            href={feature.href}
            external={"external" in feature ? Boolean((feature as any).external) : false}
          />
        ))}
      </div>
      <div
        className="hx-gemini-feature-rail--right"
        aria-label="HorizonX network features"
        style={{
          position: "absolute",
          zIndex: 12,
          top: "calc(5.8rem + 4.45vw)",
          right: "clamp(1.5rem, 4.1vw, 4.5rem)",
          display: "grid",
          gap: "calc(5.17vw - 42px)",
          width: "clamp(230px, 20.5vw, 300px)",
        }}
      >
        {rightFeatures.map((feature) => (
          <FeatureRow
            key={feature.label}
            label={feature.label}
            icon={feature.icon}
            color={featureColors[4 - feature.path]}
            side="right"
            href={feature.href}
            external={"external" in feature ? Boolean((feature as any).external) : false}
          />
        ))}
      </div>

      <style>{`
        .hx-gemini-feature-row:hover {
          filter: brightness(1.22);
          transform: translateY(-1px);
        }
        .hx-gemini-feature-row:focus-visible {
          outline: 2px solid rgba(220, 225, 255, .9);
          outline-offset: 5px;
        }
        @media (max-width: 1100px) {
          .hx-gemini-feature-rail--left,
          .hx-gemini-feature-rail--right {
            width: min(24vw, 250px) !important;
          }
          .hx-gemini-feature-icon {
            width: 36px !important;
            height: 36px !important;
            flex-basis: 36px !important;
            border-radius: 10px !important;
          }
          .hx-gemini-feature-icon svg {
            width: 19px;
            height: 19px;
          }
          .hx-gemini-feature-row:hover {
            filter: brightness(1.22);
            transform: translateY(-1px);
          }
          .hx-gemini-feature-row:focus-visible {
            outline: 2px solid rgba(220, 225, 255, .9);
            outline-offset: 5px;
          }
          .hx-gemini-feature-label {
            font-size: 12px !important;
            padding: 3px 6px !important;
          }
        }
        @media (max-width: 760px) {
          .hx-gemini-feature-rail--left,
          .hx-gemini-feature-rail--right {
            top: calc(7.2rem + 4.45vw) !important;
            width: min(28vw, 205px) !important;
            gap: calc(5.17vw - 36px) !important;
          }
          .hx-gemini-feature-rail--left { left: .7rem !important; }
          .hx-gemini-feature-rail--right { right: .7rem !important; }
          .hx-gemini-feature-icon {
            width: 32px !important;
            height: 32px !important;
            flex-basis: 32px !important;
            border-radius: 9px !important;
          }
          .hx-gemini-feature-label {
            font-size: 10px !important;
            padding: 3px 5px !important;
          }
          .hx-gemini-feature-row { gap: 7px !important; }
        }
        @media (max-width: 520px) {
          .hx-gemini-feature-rail--left,
          .hx-gemini-feature-rail--right {
            width: calc(50% - 1rem) !important;
            gap: 1.2rem !important;
          }
          .hx-gemini-feature-rail--left { left: .35rem !important; }
          .hx-gemini-feature-rail--right { right: .35rem !important; }
          .hx-gemini-feature-icon {
            width: 28px !important;
            height: 28px !important;
            flex-basis: 28px !important;
          }
          .hx-gemini-feature-icon svg { width: 16px; height: 16px; }
          .hx-gemini-feature-label { font-size: 9px !important; }
        }
      `}</style>

      <div className="pointer-events-none absolute left-1/2 z-20 flex -translate-x-1/2 justify-center top-[clamp(17rem,20vw,21rem)]">
        <span className="rounded-full border border-white/15 bg-[#f5f2ff] px-5 py-2.5 text-xs font-bold tracking-wide text-[#171126] shadow-[0_8px_36px_rgba(139,92,246,.16)] sm:text-sm">
          HORIZONX NETWORK
        </span>
      </div>

      <svg
        width="1440"
        height="400"
        viewBox="0 300 1440 400"
        xmlns="http://www.w3.org/2000/svg"
        className="pointer-events-none absolute top-28 left-1/2 h-auto w-full max-w-none -translate-x-1/2 overflow-visible"
        preserveAspectRatio="xMidYMid meet"
        aria-hidden="true"
      >
        {paths.map((path, index) => (
          <React.Fragment key={path.color}>
            <motion.path
              d={path.d}
              stroke={path.color}
              strokeWidth="2"
              fill="none"
              initial={{ pathLength: 0 }}
              style={{ pathLength: pathLengths[index] }}
              transition={transition}
            />
            <path
              d={path.d}
              stroke={path.color}
              strokeWidth="2"
              fill="none"
              pathLength={1}
              filter="url(#horizonx-gemini-blur)"
              opacity=".55"
            />
          </React.Fragment>
        ))}
        {/* Hide only the outer tails before the feature labels: left-side lines begin
            after their labels, while right-side lines end before their labels. */}
        <rect x="0" y="300" width="170" height="400" fill="#080a17" />
        <rect x="1270" y="300" width="170" height="400" fill="#080a17" />
        <defs>
          <filter id="horizonx-gemini-blur">
            <feGaussianBlur in="SourceGraphic" stdDeviation="5" />
          </filter>
        </defs>
      </svg>
    </div>
  );
}
