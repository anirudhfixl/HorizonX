"use client";

import React, { useState, useMemo } from "react";
import Link from "next/link";
import { StatusBadge } from "@/components/shared/status-badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { useWallet } from "@/contexts/wallet-context";
import { useModal } from "@/contexts/modal-context";
import { MOCK_TOKENS, MOCK_PROJECTS } from "@/lib/mock-data";
import { Token, TokenMarketData, Project } from "@/types";
import { SimulatedTokenReceipt, calculateBaseUnits } from "./token-creation-wizard";
import { formatNumber } from "./token-detail-hub";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import {
  Coins,
  Plus,
  Wallet,
  Shield,
  Copy,
  Check,
  Search,
  Flame,
  ShieldCheck,
  ArrowRight,
  Sparkles,
  Sliders,
  Send,
  Pause,
  Play,
  RotateCcw,
} from "lucide-react";

export type TokenWithMarket = Token & { market: TokenMarketData };

export interface MyTokensMetrics {
  managedTokens: number;
  aggregateSupplyRaw: bigint;
  aggregateSupplyFormatted: string;
  activeCatalogAssets: number;
  simulatedCreatorAssets: number;
}

/**
 * Filter catalog tokens created by the given wallet address (case-insensitive).
 */
export function resolveCreatorTokens(
  tokens: TokenWithMarket[],
  address?: string | null
): TokenWithMarket[] {
  if (!address) return [];
  const normalized = address.toLowerCase();
  return tokens.filter(
    (t) => t.creatorAddress && t.creatorAddress.toLowerCase() === normalized
  );
}

/**
 * Filter temporary session-simulated receipts created by the given wallet address.
 */
export function resolveSessionTokens(
  sessionReceipts: SimulatedTokenReceipt[],
  address?: string | null
): SimulatedTokenReceipt[] {
  if (!address) return [];
  const normalized = address.toLowerCase();
  return sessionReceipts.filter(
    (r) => r.creatorAddress && r.creatorAddress.toLowerCase() === normalized
  );
}

/**
 * Calculate accurate creator telemetry metrics without floating-point errors.
 */
export function calculateMyTokensMetrics(
  catalogMatches: TokenWithMarket[],
  sessionMatches: SimulatedTokenReceipt[]
): MyTokensMetrics {
  let totalRaw = BigInt(0);

  for (const t of catalogMatches) {
    const clean = (t.totalSupply || "0").replace(/[^0-9]/g, "");
    if (clean) {
      try {
        totalRaw += BigInt(clean);
      } catch {
        // ignore
      }
    }
  }

  for (const s of sessionMatches) {
    const clean = (s.totalSupply || "0").replace(/[^0-9]/g, "");
    if (clean) {
      try {
        totalRaw += BigInt(clean);
      } catch {
        // ignore
      }
    }
  }

  const activeCatalog = catalogMatches.filter((t) => t.status === "active").length;

  return {
    managedTokens: catalogMatches.length + sessionMatches.length,
    aggregateSupplyRaw: totalRaw,
    aggregateSupplyFormatted: formatNumber(Number(totalRaw)),
    activeCatalogAssets: activeCatalog,
    simulatedCreatorAssets: sessionMatches.length,
  };
}

/* ─── Page-local presentational helpers (no data, no state) ─────────────── */

interface OwnedItem {
  key: string;
  stateKey: string;
  kind: "catalog" | "session";
  name: string;
  symbol: string;
  category?: string;
  network: string;
  decimals: number;
  token?: TokenWithMarket;
  receipt?: SimulatedTokenReceipt;
}

function isSepolia(network: string): boolean {
  const n = network.toLowerCase();
  return n.includes("sepolia") || n === "ethereum";
}

function shortHex(addr?: string): string {
  if (!addr) return "—";
  return addr.length > 14 ? `${addr.slice(0, 6)}…${addr.slice(-4)}` : addr;
}

function verificationInfo(status?: string): { label: string; text: string } {
  switch (status) {
    case "audit_available":
      return { label: "Audit available", text: "A smart-contract audit is recorded for this token (demonstration data)." };
    case "contract_source_verified":
      return { label: "Source verified", text: "The contract source is recorded as verified (demonstration data)." };
    case "project_reviewed":
      return { label: "Project reviewed", text: "The linked project is recorded as reviewed; the contract itself is not (demonstration data)." };
    case "not_reviewed":
    case undefined:
      return { label: "Not reviewed", text: "No review is recorded for this token." };
    default:
      return { label: status.replace(/_/g, " "), text: "Stored verification tier on this record." };
  }
}

function SheetRow({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="grid grid-cols-1 gap-1 py-3 sm:grid-cols-[170px_minmax(0,1fr)] sm:gap-6">
      <dt className="text-xs text-muted-foreground sm:pt-0.5">{label}</dt>
      <dd className="flex min-w-0 flex-wrap items-center">{children}</dd>
    </div>
  );
}

function TimelineItem({ label, value, mono }: { label: string; value: string; mono?: boolean }) {
  return (
    <li className="relative">
      <span className="absolute -left-[25px] top-1.5 h-2 w-2 rounded-full bg-primary" aria-hidden />
      <span className="block text-xs text-muted-foreground">{label}</span>
      <span className={cn("block text-sm text-foreground", mono && "font-mono")}>{value}</span>
    </li>
  );
}

export function MyTokensHub() {
  const { isConnected, isConnecting, isReconnecting, address, shortAddress, isDemoMode, connectDemo } = useWallet();
  const { openModal } = useModal();

  // Search & Filter state
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [selectedKey, setSelectedKey] = useState<string | null>(null);

  // Client-side session tokens created in /tokens/create
  const [sessionTokens] = useState<SimulatedTokenReceipt[]>(() => {
    if (typeof window !== "undefined") {
      try {
        const stored = sessionStorage.getItem("prominers_session_tokens");
        if (stored) {
          const parsed = JSON.parse(stored);
          if (Array.isArray(parsed)) return parsed;
        }
      } catch {
        // ignore
      }
    }
    return [];
  });
  const [copiedAddress, setCopiedAddress] = useState<string | null>(null);

  // Local simulated state overrides for management actions
  const [localSupplies, setLocalSupplies] = useState<Record<string, bigint>>({});
  const [localPaused, setLocalPaused] = useState<Record<string, boolean>>({});
  const [localOwners, setLocalOwners] = useState<Record<string, string>>({});

  // Simulated Management Dialog State
  const [managementToken, setManagementToken] = useState<{
    id: string;
    name: string;
    symbol: string;
    decimals: number;
    totalSupply: string;
    contractAddress: string;
    isSessionToken?: boolean;
  } | null>(null);

  const [activeDialogTab, setActiveDialogTab] = useState<"mint" | "burn" | "pause" | "transfer">("mint");
  const [mintRecipient, setMintRecipient] = useState("");
  const [mintAmount, setMintAmount] = useState("");
  const [burnAmount, setBurnAmount] = useState("");
  const [newOwnerAddress, setNewOwnerAddress] = useState("");
  const [confirmTransfer, setConfirmTransfer] = useState(false);

  // Project map for quick lookup
  const projectMap = useMemo(() => {
    const map = new Map<string, Project>();
    for (const p of MOCK_PROJECTS) {
      map.set(p.id, p);
    }
    return map;
  }, []);

  // Filter creator tokens based on active connected/demo address
  const catalogMatches = useMemo(() => {
    return resolveCreatorTokens(MOCK_TOKENS, address);
  }, [address]);

  const sessionMatches = useMemo(() => {
    return resolveSessionTokens(sessionTokens, address);
  }, [sessionTokens, address]);

  // Aggregate metrics
  const metrics = useMemo(() => {
    return calculateMyTokensMetrics(catalogMatches, sessionMatches);
  }, [catalogMatches, sessionMatches]);

  // Combined searchable/filterable items
  const filteredCatalogTokens = useMemo(() => {
    return catalogMatches.filter((t) => {
      const matchSearch =
        searchQuery === "" ||
        t.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        t.symbol.toLowerCase().includes(searchQuery.toLowerCase());
      const matchCat = selectedCategory === "all" || t.category === selectedCategory;
      return matchSearch && matchCat;
    });
  }, [catalogMatches, searchQuery, selectedCategory]);

  const filteredSessionTokens = useMemo(() => {
    return sessionMatches.filter((s) => {
      const matchSearch =
        searchQuery === "" ||
        s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        s.symbol.toLowerCase().includes(searchQuery.toLowerCase());
      const matchCat = selectedCategory === "all" || s.category === selectedCategory;
      return matchSearch && matchCat;
    });
  }, [sessionMatches, searchQuery, selectedCategory]);

  const handleCopy = (text: string) => {
    if (typeof navigator !== "undefined" && navigator.clipboard) {
      navigator.clipboard.writeText(text).then(
        () => {
          setCopiedAddress(text);
          setTimeout(() => setCopiedAddress(null), 2000);
          toast.success("Address Copied", { description: text });
        },
        () => toast.error("Copy Failed", { description: "Clipboard access was denied by the browser." })
      );
    }
  };

  const openManagementModal = (token: {
    id: string;
    name: string;
    symbol: string;
    decimals: number;
    totalSupply: string;
    contractAddress: string;
    isSessionToken?: boolean;
  }) => {
    setManagementToken(token);
    setActiveDialogTab("mint");
    setMintRecipient(address || "");
    setMintAmount("");
    setBurnAmount("");
    setNewOwnerAddress("");
    setConfirmTransfer(false);
  };

  const handleSimulateMint = (e: React.FormEvent) => {
    e.preventDefault();
    if (!managementToken) return;

    if (!mintRecipient || !mintRecipient.startsWith("0x") || mintRecipient.length !== 42) {
      toast.error("Invalid Recipient", { description: "Please enter a valid 42-character EVM address." });
      return;
    }

    const calc = calculateBaseUnits(mintAmount, managementToken.decimals);
    if (!calc.isValid) {
      toast.error("Invalid Amount", { description: calc.error || "Please enter a positive mint amount." });
      return;
    }

    const currentSupply = localSupplies[managementToken.id] ?? BigInt(managementToken.totalSupply.replace(/[^0-9]/g, "") || "0");
    const nextSupply = currentSupply + calc.rawSupply;

    setLocalSupplies((prev) => ({ ...prev, [managementToken.id]: nextSupply }));
    toast.success("Simulated Mint Complete (Local State)", {
      description: `Simulated ${mintAmount} ${managementToken.symbol} minted to ${mintRecipient.slice(0, 6)}... (Note: In-memory simulation state resets upon page reload).`,
    });
    setMintAmount("");
  };

  const handleSimulateBurn = (e: React.FormEvent) => {
    e.preventDefault();
    if (!managementToken) return;

    const calc = calculateBaseUnits(burnAmount, managementToken.decimals);
    if (!calc.isValid) {
      toast.error("Invalid Amount", { description: calc.error || "Please enter a positive burn amount." });
      return;
    }

    const currentSupply = localSupplies[managementToken.id] ?? BigInt(managementToken.totalSupply.replace(/[^0-9]/g, "") || "0");
    if (calc.rawSupply > currentSupply) {
      toast.error("Excessive Burn", { description: "Burn amount exceeds the current token supply." });
      return;
    }

    const nextSupply = currentSupply - calc.rawSupply;
    setLocalSupplies((prev) => ({ ...prev, [managementToken.id]: nextSupply }));
    toast.success("Simulated Burn Complete (Local State)", {
      description: `Simulated ${burnAmount} ${managementToken.symbol} burned. Supply reduced locally.`,
    });
    setBurnAmount("");
  };

  const handleSimulateTogglePause = () => {
    if (!managementToken) return;
    const isCurrentlyPaused = localPaused[managementToken.id] || false;
    const nextPaused = !isCurrentlyPaused;

    setLocalPaused((prev) => ({ ...prev, [managementToken.id]: nextPaused }));
    toast.success(`Simulated Contract ${nextPaused ? "Paused" : "Resumed"}`, {
      description: `Token transfers locally ${nextPaused ? "halted" : "resumed"}. Note: Subject to Architecture Decision D-06 review.`,
    });
  };

  const handleSimulateTransferOwnership = (e: React.FormEvent) => {
    e.preventDefault();
    if (!managementToken) return;

    if (!newOwnerAddress || !newOwnerAddress.startsWith("0x") || newOwnerAddress.length !== 42) {
      toast.error("Invalid Address", { description: "Please enter a valid 42-character recipient address." });
      return;
    }

    if (!confirmTransfer) {
      toast.error("Confirmation Required", { description: "Please confirm that you understand this is a simulation preview." });
      return;
    }

    setLocalOwners((prev) => ({ ...prev, [managementToken.id]: newOwnerAddress }));
    toast.success("Simulated Ownership Transferred", {
      description: `Admin authority transferred locally to ${newOwnerAddress.slice(0, 6)}... (Pending D-06 review).`,
    });
    setNewOwnerAddress("");
    setConfirmTransfer(false);
  };
  // ── Owned-token workspace model ──────────────────────────────────────────
  const items = useMemo<OwnedItem[]>(() => {
    const cat: OwnedItem[] = filteredCatalogTokens.map((token) => ({
      key: `c:${token.id}`,
      stateKey: token.id,
      kind: "catalog",
      name: token.name,
      symbol: token.symbol,
      category: token.category,
      network: token.network,
      decimals: token.decimals || 18,
      token,
    }));
    const ses: OwnedItem[] = filteredSessionTokens.map((receipt) => ({
      key: `s:${receipt.contractAddress}`,
      stateKey: receipt.contractAddress,
      kind: "session",
      name: receipt.name,
      symbol: receipt.symbol,
      category: receipt.category,
      network: "Ethereum Sepolia",
      decimals: receipt.decimals,
      receipt,
    }));
    return [...cat, ...ses];
  }, [filteredCatalogTokens, filteredSessionTokens]);

  const ownedCategories = useMemo(() => {
    const set = new Set<string>();
    catalogMatches.forEach((t) => t.category && set.add(t.category));
    sessionMatches.forEach((s) => s.category && set.add(s.category));
    return Array.from(set).sort();
  }, [catalogMatches, sessionMatches]);

  const selected = items.find((i) => i.key === selectedKey) ?? items[0];
  const walletPending = !isConnected && (isConnecting || isReconnecting);
  const isFiltering = searchQuery.trim() !== "" || selectedCategory !== "all";

  const openAdmin = (item: OwnedItem) => {
    const supplyShown = localSupplies[item.stateKey]
      ? formatNumber(Number(localSupplies[item.stateKey]))
      : item.token
      ? item.token.totalSupply || "0"
      : item.receipt!.totalSupply;
    openManagementModal({
      id: item.stateKey,
      name: item.name,
      symbol: item.symbol,
      decimals: item.decimals,
      totalSupply: String(supplyShown),
      contractAddress:
        item.token?.contractAddress || item.receipt?.contractAddress || "0x0000000000000000000000000000000000000000",
      isSessionToken: item.kind === "session",
    });
  };

  const renderDetail = (item: OwnedItem) => {
    const t = item.token;
    const r = item.receipt;
    const project = t?.projectId ? projectMap.get(t.projectId) : undefined;
    const isPaused = localPaused[item.stateKey] || false;
    const supplyOverride = localSupplies[item.stateKey];
    const supply = supplyOverride ? formatNumber(Number(supplyOverride)) : t ? t.totalSupply || "—" : r!.totalSupply;
    const ownerOverride = localOwners[item.stateKey];
    const owner = ownerOverride || t?.creatorAddress || r?.creatorAddress || address || "";
    const contract = t?.contractAddress || r?.contractAddress;
    const isSession = item.kind === "session";
    const verification = t ? verificationInfo(t.verificationStatus) : null;
    const tone = isSession ? "border-amber-500/30 from-amber-500/25 to-amber-500/5 text-amber-400" : "border-primary/30 from-primary/25 to-primary/5 text-primary";
    const features = t?.features ?? r?.features ?? [];

    return (
      <section aria-label={`${item.name} workspace`} className="min-w-0 space-y-10">
        {/* Identity + actions */}
        <div className="space-y-5">
          <div className="flex items-start gap-4">
            <span className={cn("flex h-16 w-16 shrink-0 items-center justify-center rounded-2xl border bg-gradient-to-br font-mono text-lg font-bold", tone)}>
              {item.symbol.slice(0, 3)}
            </span>
            <div className="min-w-0 space-y-1.5">
              <div className="flex flex-wrap items-center gap-x-3 gap-y-1.5">
                <h2 className="text-2xl font-semibold tracking-tight text-foreground sm:text-3xl">{item.name}</h2>
                {t && <StatusBadge status={t.status} />}
                {isSession && (
                  <span className="rounded-full border border-amber-500/30 bg-amber-500/10 px-2.5 py-0.5 text-[11px] font-semibold text-amber-400">
                    Simulated · this session
                  </span>
                )}
                {isPaused && (
                  <span className="rounded-full border border-amber-500/30 bg-amber-500/10 px-2.5 py-0.5 text-[11px] font-semibold text-amber-400">
                    Paused · simulated
                  </span>
                )}
              </div>
              <p className="text-sm">
                <span className="font-mono text-muted-foreground">${item.symbol}</span>
                {item.category && <span className="text-muted-foreground/50"> · </span>}
                {item.category && <span className="font-medium text-foreground">{item.category}</span>}
              </p>
              {(t?.description || r?.description) && (
                <p className="max-w-2xl pt-1 text-sm leading-relaxed text-muted-foreground">{t?.description || r?.description}</p>
              )}
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-x-5 gap-y-3">
            <Button size="sm" onClick={() => openAdmin(item)} className="h-9 gap-1.5 bg-primary text-xs font-semibold text-primary-foreground">
              <Sliders className="h-3.5 w-3.5" /> {isSession ? "Simulate Admin Actions" : "Simulate Admin"}
            </Button>
            {t ? (
              <nav aria-label="Token pages" className="flex flex-wrap items-center gap-x-5 gap-y-2 text-sm">
                <Link href={`/tokens/${t.id}`} className="inline-flex items-center gap-1 font-medium text-foreground hover:text-primary">
                  View Token Hub <ArrowRight className="h-3.5 w-3.5" />
                </Link>
                <Link href={`/tokens/${t.id}/contract`} className="text-muted-foreground hover:text-primary">Contract</Link>
                <Link href={`/tokens/${t.id}/activity`} className="text-muted-foreground hover:text-primary">Activity</Link>
              </nav>
            ) : (
              <span className="text-xs text-muted-foreground">Session simulations have no token page, because they are not in the catalog.</span>
            )}
          </div>
        </div>

        {/* Contract sheet */}
        <div className="space-y-3">
          <h3 className="text-[11px] font-semibold uppercase tracking-[0.2em] text-muted-foreground">Contract sheet</h3>
          <dl className="divide-y divide-border/40 border-y border-border/40 text-sm">
            {contract && (
              <SheetRow label="Contract address">
                <span className="break-all font-mono text-xs text-foreground sm:text-sm">{contract}</span>
                <button
                  type="button"
                  onClick={() => handleCopy(contract)}
                  aria-label={`Copy ${item.symbol} contract address`}
                  className="ml-2 inline-flex shrink-0 items-center gap-1 rounded text-[11px] text-muted-foreground hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
                >
                  {copiedAddress === contract ? <Check className="h-3 w-3 text-emerald-400" /> : <Copy className="h-3 w-3" />}
                  <span>{copiedAddress === contract ? "Copied" : "Copy"}</span>
                </button>
              </SheetRow>
            )}
            <SheetRow label="Network">
              <span className={cn("font-mono text-sm", isSepolia(item.network) ? "text-primary" : "text-muted-foreground")}>
                {isSession ? "Ethereum Sepolia (11155111)" : item.network}
              </span>
              {!isSepolia(item.network) && (
                <span className="ml-2 text-xs text-muted-foreground">Catalog entry only; not a supported wallet network (D-04)</span>
              )}
            </SheetRow>
            {t?.standard && <SheetRow label="Standard"><span className="font-mono text-sm text-foreground">{t.standard}</span></SheetRow>}
            <SheetRow label="Decimals"><span className="font-mono text-sm text-foreground">{item.decimals}</span></SheetRow>
            <SheetRow label={isSession ? "Simulated supply" : "Supply"}>
              <span className="font-mono text-sm font-semibold text-foreground">{supply}</span>
              {supplyOverride && <span className="ml-2 text-xs text-amber-400">changed in local simulation</span>}
            </SheetRow>
            <SheetRow label="Admin authority">
              <span className="font-mono text-sm text-foreground">{owner ? shortHex(owner) : "Deployer"}</span>
              {ownerOverride && <span className="ml-2 text-xs text-amber-400">transferred in local simulation</span>}
            </SheetRow>
            <SheetRow label="Pause state">
              <span className={cn("text-sm font-medium", isPaused ? "text-amber-400" : "text-emerald-400")}>
                {isPaused ? "Paused (transfers halted, simulated)" : "Not paused"}
              </span>
              <span className="ml-2 text-xs text-muted-foreground">Local preview state</span>
            </SheetRow>
            {project && (
              <SheetRow label="Linked project">
                <Link href={`/projects/${project.id}`} className="text-sm font-medium text-foreground hover:text-primary">{project.name}</Link>
              </SheetRow>
            )}
          </dl>
        </div>

        {/* Status, verification and record */}
        <div className="grid grid-cols-1 gap-10 xl:grid-cols-2">
          <div className="space-y-3">
            <h3 className="text-[11px] font-semibold uppercase tracking-[0.2em] text-muted-foreground">Status and verification</h3>
            {t && verification ? (
              <div className="space-y-4 text-sm">
                <div>
                  <p className="flex items-center gap-2 font-medium text-foreground">
                    <span className="text-muted-foreground">Record status</span> <StatusBadge status={t.status} />
                  </p>
                  <p className="mt-1 text-xs leading-relaxed text-muted-foreground">
                    The status stored on this catalog record. It is not an on-chain deployment check.
                  </p>
                </div>
                <div>
                  <p className="flex items-center gap-2 font-medium text-foreground">
                    <ShieldCheck className={cn("h-4 w-4", t.verificationStatus === "audit_available" ? "text-primary" : "text-muted-foreground")} aria-hidden />
                    {verification.label}
                  </p>
                  <p className="mt-1 text-xs leading-relaxed text-muted-foreground">{verification.text}</p>
                </div>
              </div>
            ) : (
              <p className="text-sm leading-relaxed text-muted-foreground">
                This is a simulated deployment receipt from the Token Creation Wizard. It has no catalog status or
                verification record, and nothing was broadcast to Ethereum Sepolia.
              </p>
            )}
          </div>

          <div className="space-y-3">
            <h3 className="text-[11px] font-semibold uppercase tracking-[0.2em] text-muted-foreground">Record timeline</h3>
            <ol className="relative space-y-4 border-l border-border/60 pl-5 text-sm">
              {t ? (
                <>
                  <TimelineItem label="Created" value={t.createdAt} />
                  <TimelineItem label="Last updated" value={t.updatedAt} />
                </>
              ) : (
                <>
                  <TimelineItem label="Simulated deployment" value={r!.deployedAt.slice(0, 10)} />
                  <TimelineItem label="Simulated block" value={String(r!.blockNumber)} mono />
                  <TimelineItem label="Simulated transaction" value={shortHex(r!.transactionHash)} mono />
                </>
              )}
            </ol>
          </div>
        </div>

        {features.length > 0 && (
          <div className="space-y-3">
            <h3 className="text-[11px] font-semibold uppercase tracking-[0.2em] text-muted-foreground">Features</h3>
            <ul className="flex flex-wrap gap-2">
              {features.map((f, i) => (
                <li key={i} className="rounded-full px-3 py-1 text-xs text-muted-foreground ring-1 ring-border/60">{f}</li>
              ))}
            </ul>
          </div>
        )}
      </section>
    );
  };

  return (
    <div className="mx-auto w-full max-w-[1600px] space-y-10 px-4 py-10 sm:px-6 lg:px-10">
      {/* 1. Header */}
      <header className="space-y-6">
        <nav aria-label="Breadcrumb" className="flex items-center gap-2 text-xs text-muted-foreground">
          <Link href="/tokens" className="transition-colors hover:text-foreground">Tokens</Link>
          <span aria-hidden>/</span>
          <span aria-current="page" className="text-foreground">My Tokens</span>
        </nav>

        <div className="flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
          <div className="max-w-3xl space-y-3">
            <p className="text-[11px] font-semibold uppercase tracking-[0.22em] text-primary">Tokens · Owner workspace</p>
            <h1 className="text-4xl font-semibold tracking-tight text-foreground sm:text-5xl">My Tokens</h1>
            <p className="text-sm leading-relaxed text-muted-foreground sm:text-base">
              Inspect, monitor, and simulate administrative actions for your creator assets on Ethereum Sepolia (D-04).
            </p>
          </div>
          <Button asChild size="sm" className="h-10 gap-1.5 self-start bg-primary px-4 text-sm font-semibold text-primary-foreground lg:self-auto">
            <Link href="/tokens/create">
              <Plus className="h-4 w-4" /> Deploy New Token
            </Link>
          </Button>
        </div>

        {/* Wallet identity strip */}
        <div className="flex flex-col gap-3 border-y border-border/40 py-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-3">
            <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
              <Wallet className="h-4 w-4" aria-hidden />
            </span>
            <div className="min-w-0">
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-xs font-medium text-muted-foreground">Connected Account:</span>
                {isConnected ? (
                  <span className="break-all font-mono text-xs font-semibold text-foreground">{shortAddress || address}</span>
                ) : (
                  <span className="text-xs font-semibold text-muted-foreground">{walletPending ? "Checking…" : "Not Connected"}</span>
                )}
                {isDemoMode && (
                  <span className="rounded-full border border-amber-500/30 bg-amber-500/15 px-2 py-0.5 text-[10px] font-semibold text-amber-400">
                    Demo Sandbox Identity
                  </span>
                )}
              </div>
              <p className="text-[11px] text-muted-foreground">
                {isConnected
                  ? "Ownership is matched locally: a token is listed when its creator address equals this account."
                  : "Connect your Web3 wallet to manage deployed contracts and simulate administrative functions."}
              </p>
            </div>
          </div>
          <div className="flex shrink-0 items-center gap-2">
            <span className="rounded-full border border-primary/30 bg-primary/10 px-2.5 py-0.5 font-mono text-[11px] font-medium text-primary">
              Sepolia Testnet (D-04)
            </span>
            {!isConnected && !walletPending && (
              <Button size="sm" variant="outline" onClick={connectDemo} className="border-primary/40 text-xs text-primary hover:bg-primary/10">
                <Sparkles className="mr-1 h-3.5 w-3.5 text-primary" />
                Use Demo Wallet
              </Button>
            )}
          </div>
        </div>
      </header>

      {/* 2. States */}
      {walletPending ? (
        <div role="status" aria-live="polite" className="grid grid-cols-1 gap-10 lg:grid-cols-[300px_minmax(0,1fr)]" data-testid="wallet-loading">
          <div className="space-y-3">
            {[0, 1, 2].map((i) => (
              <div key={i} className="flex animate-pulse items-center gap-3 py-2">
                <div className="h-10 w-10 rounded-xl bg-secondary/60" />
                <div className="flex-1 space-y-2">
                  <div className="h-3 w-3/4 rounded bg-secondary/60" />
                  <div className="h-2.5 w-1/2 rounded bg-secondary/40" />
                </div>
              </div>
            ))}
          </div>
          <div className="space-y-4">
            <div className="h-8 w-1/2 animate-pulse rounded bg-secondary/60" />
            <div className="h-40 animate-pulse rounded-2xl bg-secondary/30" />
            <span className="sr-only">Checking wallet connection…</span>
          </div>
        </div>
      ) : !isConnected ? (
        <section aria-label="Wallet required" className="grid grid-cols-1 gap-10 border-t border-border/40 pt-10 lg:grid-cols-[minmax(0,1fr)_minmax(0,1fr)] lg:gap-16">
          <div className="space-y-5">
            <Wallet className="h-8 w-8 text-primary" aria-hidden />
            <h2 className="text-2xl font-semibold tracking-tight text-foreground">Connect Your Web3 Wallet</h2>
            <p className="max-w-lg text-sm leading-relaxed text-muted-foreground">
              Connect your Ethereum Sepolia wallet to inspect your deployed token contracts, review creator permissions, and test simulated administrative actions.
            </p>
            <div className="flex flex-col items-start gap-3 sm:flex-row sm:items-center">
              <Button size="sm" onClick={() => openModal("CONNECT_WALLET")} className="bg-primary text-xs font-semibold text-primary-foreground hover:bg-primary/90">
                Connect Wallet
              </Button>
              <Button size="sm" variant="outline" onClick={connectDemo} className="border-primary/40 text-xs font-semibold text-primary hover:bg-primary/10">
                <Sparkles className="mr-1 h-3.5 w-3.5" />
                Explore Demo Creator Assets
              </Button>
            </div>
          </div>
          <div className="space-y-4">
            <h3 className="text-[11px] font-semibold uppercase tracking-[0.2em] text-muted-foreground">Once connected, this workspace shows</h3>
            <ul className="divide-y divide-border/40 border-y border-border/40 text-sm">
              <li className="py-3"><span className="font-medium text-foreground">Tokens created by your address</span><span className="block text-xs text-muted-foreground">Catalog records and session simulations, listed separately.</span></li>
              <li className="py-3"><span className="font-medium text-foreground">Contract sheet per token</span><span className="block text-xs text-muted-foreground">Network, address, decimals, supply, admin authority and linked project.</span></li>
              <li className="py-3"><span className="font-medium text-foreground">Status and verification</span><span className="block text-xs text-muted-foreground">Taken from the stored record, with links to the token, contract and activity pages.</span></li>
            </ul>
          </div>
        </section>
      ) : metrics.managedTokens === 0 ? (
        <section aria-label="No tokens" className="grid grid-cols-1 gap-10 border-t border-border/40 pt-10 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.1fr)] lg:gap-16">
          <div className="space-y-5">
            <Coins className="h-8 w-8 text-primary" aria-hidden />
            <h2 className="text-2xl font-semibold tracking-tight text-foreground">No Tokens Created With This Address</h2>
            <p className="max-w-lg text-sm leading-relaxed text-muted-foreground">
              You have not deployed or simulated any token contracts with this wallet yet. Configure your specifications and launch your first ERC-20 token in under 60 seconds.
            </p>
            <div className="flex flex-wrap items-center gap-x-5 gap-y-3">
              <Button asChild size="sm" className="bg-primary text-xs font-semibold text-primary-foreground hover:bg-primary/90">
                <Link href="/tokens/create">Deploy Your First Token</Link>
              </Button>
              <Link href="/tokens/explore" className="text-sm text-muted-foreground hover:text-primary">Browse the token explorer</Link>
            </div>
          </div>
          <div className="space-y-4">
            <h3 className="text-[11px] font-semibold uppercase tracking-[0.2em] text-muted-foreground">How Token Deployment Works on ProMiners</h3>
            <ol className="space-y-5">
              {[
                ["Configure Identity & Supply", "Specify your token ticker, total supply, decimals, and link your ecosystem project for directory indexing."],
                ["Inspect Source Templates", "Preview OpenZeppelin v5-compliant Solidity contracts with proposed Burnable, Mintable, and Pausable extensions."],
                ["Simulate Sepolia Deployment", "Walk through the 6-stage deployment simulator to generate preview receipts and manage contract states in your hub."],
              ].map(([title, text], i) => (
                <li key={title} className="flex gap-4">
                  <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-primary/15 font-mono text-xs font-bold text-primary">{i + 1}</span>
                  <span>
                    <span className="block text-sm font-semibold text-foreground">{title}</span>
                    <span className="block text-xs leading-relaxed text-muted-foreground">{text}</span>
                  </span>
                </li>
              ))}
            </ol>
          </div>
        </section>
      ) : (
        <div className="space-y-8">
          {/* Summary line */}
          <dl className="flex flex-wrap gap-x-10 gap-y-3 text-xs">
            <div className="flex items-baseline gap-2"><dt className="text-muted-foreground">Managed tokens</dt><dd className="font-mono text-base font-semibold text-foreground">{metrics.managedTokens}</dd></div>
            <div className="flex items-baseline gap-2"><dt className="text-muted-foreground">Active in catalog</dt><dd className="font-mono text-base font-semibold text-foreground">{metrics.activeCatalogAssets}</dd></div>
            <div className="flex items-baseline gap-2"><dt className="text-muted-foreground">Session simulations</dt><dd className="font-mono text-base font-semibold text-foreground">{metrics.simulatedCreatorAssets}</dd></div>
            <div className="flex items-baseline gap-2"><dt className="text-muted-foreground">Sum of listed supplies</dt><dd className="font-mono text-base font-semibold text-foreground">{metrics.aggregateSupplyFormatted}</dd></div>
          </dl>

          {/* Simulation boundary */}
          <div className="flex flex-col gap-3 border-l-2 border-primary/50 pl-4 text-xs leading-relaxed text-muted-foreground sm:flex-row sm:items-start sm:justify-between">
            <span className="flex items-start gap-2.5">
              <Shield className="mt-0.5 h-3.5 w-3.5 shrink-0 text-primary" aria-hidden />
              <span>
                <span className="font-semibold text-foreground">Simulation Boundary: </span>
                Token management in this hub operates strictly in local preview mode. Administrative minting, burning, pause toggles, and ownership transfers simulate state changes for UI evaluation and do not broadcast transactions to Ethereum Sepolia. Module capabilities (Burnable, Mintable, Pausable) remain subject to pending Architecture Decisions <code className="font-mono text-primary">D-05</code> and <code className="font-mono text-primary">D-06</code>.
              </span>
            </span>
            <span className="shrink-0 self-start rounded-full border border-primary/30 px-2.5 py-0.5 font-mono text-[11px] font-semibold text-primary">Preview Mode</span>
          </div>

          {/* Master / detail */}
          <div className="grid grid-cols-1 gap-8 lg:grid-cols-[300px_minmax(0,1fr)] lg:gap-12">
            <aside aria-label="Your tokens" className="min-w-0 space-y-4 lg:sticky lg:top-24 lg:self-start">
              <div className="space-y-2">
                <div className="relative">
                  <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" aria-hidden />
                  <Input
                    placeholder="Filter managed tokens by name or ticker..."
                    aria-label="Filter managed tokens"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="border-border/60 bg-secondary/40 pl-9 text-xs"
                  />
                </div>
                <div className="flex items-center gap-2">
                  <label htmlFor="my-token-category" className="whitespace-nowrap text-xs text-muted-foreground">Category:</label>
                  <select
                    id="my-token-category"
                    aria-label="Filter tokens by category"
                    value={selectedCategory}
                    onChange={(e) => setSelectedCategory(e.target.value)}
                    className="h-9 w-full rounded-lg border border-border/60 bg-secondary/40 px-3 text-xs text-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-primary"
                  >
                    <option value="all">All Categories</option>
                    {ownedCategories.map((c) => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>
                </div>
              </div>

              {items.length === 0 ? (
                <div className="space-y-3 py-6 text-sm text-muted-foreground">
                  <p>No managed tokens match the current filter.</p>
                  {isFiltering && (
                    <Button size="sm" variant="outline" onClick={() => { setSearchQuery(""); setSelectedCategory("all"); }} className="text-xs">
                      Clear filter
                    </Button>
                  )}
                </div>
              ) : (
                <ul className="-mx-4 flex gap-2 overflow-x-auto px-4 pb-1 sm:-mx-6 sm:px-6 lg:mx-0 lg:flex-col lg:gap-0 lg:overflow-visible lg:px-0 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
                  {items.map((it, idx) => {
                    const active = selected?.key === it.key;
                    const showGroup = idx === 0 || items[idx - 1].kind !== it.kind;
                    return (
                      <li key={it.key} className="shrink-0 lg:shrink">
                        {showGroup && (
                          <p className="hidden px-3 pb-1 pt-4 text-[11px] font-semibold uppercase tracking-[0.2em] text-muted-foreground first:pt-0 lg:block">
                            {it.kind === "catalog" ? "Catalog" : "This session · simulated"}
                          </p>
                        )}
                        <button
                          type="button"
                          onClick={() => setSelectedKey(it.key)}
                          aria-pressed={active}
                          aria-label={`${it.name}, ${it.symbol}${it.kind === "session" ? ", simulated this session" : ""}`}
                          className={cn(
                            "flex w-full items-center gap-3 rounded-xl border-l-2 px-3 py-2.5 text-left transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary",
                            active ? "border-primary bg-primary/10" : "border-transparent hover:bg-secondary/40"
                          )}
                        >
                          <span className={cn("flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border bg-gradient-to-br font-mono text-[11px] font-bold", it.kind === "session" ? "border-amber-500/30 from-amber-500/25 to-amber-500/5 text-amber-400" : "border-primary/30 from-primary/25 to-primary/5 text-primary")}>
                            {it.symbol.slice(0, 3)}
                          </span>
                          <span className="min-w-0">
                            <span className={cn("block truncate text-sm font-semibold", active ? "text-foreground" : "text-foreground/90")}>
                              <span className="lg:hidden">${it.symbol}</span>
                              <span className="hidden lg:inline">{it.name}</span>
                            </span>
                            <span className="hidden truncate text-xs text-muted-foreground lg:block">
                              <span className="font-mono">${it.symbol}</span>
                              {it.token && <span> · {it.token.status}</span>}
                              {it.kind === "session" && <span> · simulated</span>}
                            </span>
                          </span>
                        </button>
                      </li>
                    );
                  })}
                </ul>
              )}
            </aside>

            <div className="min-w-0">
              {selected ? (
                renderDetail(selected)
              ) : (
                <div className="py-16 text-center text-sm text-muted-foreground">Select a token to see its workspace.</div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* 6. Simulated Creator Actions Dialog */}
      {managementToken && (
        <Dialog open={Boolean(managementToken)} onOpenChange={(open) => !open && setManagementToken(null)}>
          <DialogContent className="max-w-md bg-card/95 border-border/60 backdrop-blur-xl">
            <DialogHeader>
              <div className="inline-flex items-center gap-1.5 rounded-full border border-primary/30 bg-primary/10 px-2.5 py-0.5 text-[10px] font-semibold text-primary w-fit">
                <span>Simulated Administration (D-04 Preview)</span>
              </div>
              <DialogTitle className="text-base font-bold text-foreground">
                Manage {managementToken.name} (${managementToken.symbol})
              </DialogTitle>
              <DialogDescription className="text-xs text-muted-foreground">
                Simulate contract owner actions for this asset. No actual transactions or signatures are submitted to Ethereum Sepolia.
              </DialogDescription>
            </DialogHeader>

            {/* Action Tabs */}
            <div className="grid grid-cols-4 gap-1 border-b border-border/40 pb-2 text-center text-xs">
              <button
                type="button"
                onClick={() => setActiveDialogTab("mint")}
                className={`py-1.5 rounded-lg font-semibold transition-colors ${
                  activeDialogTab === "mint"
                    ? "bg-primary text-primary-foreground"
                    : "text-muted-foreground hover:bg-secondary/40"
                }`}
              >
                Mint
              </button>
              <button
                type="button"
                onClick={() => setActiveDialogTab("burn")}
                className={`py-1.5 rounded-lg font-semibold transition-colors ${
                  activeDialogTab === "burn"
                    ? "bg-primary text-primary-foreground"
                    : "text-muted-foreground hover:bg-secondary/40"
                }`}
              >
                Burn
              </button>
              <button
                type="button"
                onClick={() => setActiveDialogTab("pause")}
                className={`py-1.5 rounded-lg font-semibold transition-colors ${
                  activeDialogTab === "pause"
                    ? "bg-primary text-primary-foreground"
                    : "text-muted-foreground hover:bg-secondary/40"
                }`}
              >
                Pause
              </button>
              <button
                type="button"
                onClick={() => setActiveDialogTab("transfer")}
                className={`py-1.5 rounded-lg font-semibold transition-colors ${
                  activeDialogTab === "transfer"
                    ? "bg-primary text-primary-foreground"
                    : "text-muted-foreground hover:bg-secondary/40"
                }`}
              >
                Owner
              </button>
            </div>

            {/* Mint Tab */}
            {activeDialogTab === "mint" && (
              <form onSubmit={handleSimulateMint} className="space-y-4 pt-2">
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium text-foreground">Recipient EVM Address</Label>
                  <Input
                    placeholder="0x..."
                    value={mintRecipient}
                    onChange={(e) => setMintRecipient(e.target.value)}
                    className="text-xs font-mono bg-secondary/20"
                  />
                  <p className="text-[10px] text-muted-foreground">Defaults to your active creator address.</p>
                </div>

                <div className="space-y-1.5">
                  <Label className="text-xs font-medium text-foreground">Tokens to Mint</Label>
                  <Input
                    placeholder="e.g. 500,000"
                    value={mintAmount}
                    onChange={(e) => setMintAmount(e.target.value)}
                    className="text-xs font-mono bg-secondary/20"
                  />
                </div>

                <div className="rounded-xl border border-border/40 bg-secondary/20 p-2.5 text-[11px] text-muted-foreground">
                  <span className="font-semibold text-foreground">D-05/D-06 Notice: </span>
                  Minting functions are proposed configuration features subject to review. This interaction updates local session state only.
                </div>

                <DialogFooter className="pt-2">
                  <Button type="button" variant="outline" size="sm" onClick={() => setManagementToken(null)} className="text-xs">
                    Cancel
                  </Button>
                  <Button type="submit" size="sm" className="bg-primary hover:bg-primary/90 text-primary-foreground text-xs font-semibold">
                    <Send className="h-3.5 w-3.5 mr-1" /> Simulate Mint
                  </Button>
                </DialogFooter>
              </form>
            )}

            {/* Burn Tab */}
            {activeDialogTab === "burn" && (
              <form onSubmit={handleSimulateBurn} className="space-y-4 pt-2">
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium text-foreground">Tokens to Burn</Label>
                  <Input
                    placeholder="e.g. 100,000"
                    value={burnAmount}
                    onChange={(e) => setBurnAmount(e.target.value)}
                    className="text-xs font-mono bg-secondary/20"
                  />
                  <p className="text-[10px] text-muted-foreground">
                    Current Supply: {localSupplies[managementToken.id] ? formatNumber(Number(localSupplies[managementToken.id])) : managementToken.totalSupply} {managementToken.symbol}
                  </p>
                </div>

                <div className="rounded-xl border border-rose-500/20 bg-rose-500/5 p-2.5 text-[11px] text-muted-foreground">
                  <span className="font-semibold text-rose-300">Burn Warning: </span>
                  Simulating a token burn permanently reduces local supply base units for this asset.
                </div>

                <DialogFooter className="pt-2">
                  <Button type="button" variant="outline" size="sm" onClick={() => setManagementToken(null)} className="text-xs">
                    Cancel
                  </Button>
                  <Button type="submit" size="sm" className="bg-rose-500 hover:bg-rose-600 text-white text-xs font-semibold">
                    <Flame className="h-3.5 w-3.5 mr-1" /> Simulate Burn
                  </Button>
                </DialogFooter>
              </form>
            )}

            {/* Pause Tab */}
            {activeDialogTab === "pause" && (
              <div className="space-y-4 pt-2">
                <div className="rounded-xl border border-border/40 bg-secondary/20 p-3 space-y-1">
                  <div className="text-xs text-muted-foreground">Current Pause Status:</div>
                  <div className="text-sm font-bold text-foreground">
                    {localPaused[managementToken.id] ? "Contract Transfers Paused" : "Contract Active / Operational"}
                  </div>
                </div>

                <div className="rounded-xl border border-amber-500/20 bg-amber-500/5 p-2.5 text-[11px] text-muted-foreground">
                  <span className="font-semibold text-amber-300">Centralized Authority Notice (D-06): </span>
                  Emergency pause hooks introduce centralized administrative capabilities. The final upgrade and governance authority model remains under review.
                </div>

                <DialogFooter className="pt-2">
                  <Button type="button" variant="outline" size="sm" onClick={() => setManagementToken(null)} className="text-xs">
                    Cancel
                  </Button>
                  <Button
                    type="button"
                    size="sm"
                    onClick={handleSimulateTogglePause}
                    className={
                      localPaused[managementToken.id]
                        ? "bg-emerald-500 hover:bg-emerald-600 text-white text-xs font-semibold"
                        : "bg-amber-500 hover:bg-amber-600 text-white text-xs font-semibold"
                    }
                  >
                    {localPaused[managementToken.id] ? (
                      <>
                        <Play className="h-3.5 w-3.5 mr-1" /> Simulate Resume Transfers
                      </>
                    ) : (
                      <>
                        <Pause className="h-3.5 w-3.5 mr-1" /> Simulate Emergency Pause
                      </>
                    )}
                  </Button>
                </DialogFooter>
              </div>
            )}

            {/* Transfer Ownership Tab */}
            {activeDialogTab === "transfer" && (
              <form onSubmit={handleSimulateTransferOwnership} className="space-y-4 pt-2">
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium text-foreground">New Owner Address</Label>
                  <Input
                    placeholder="0x..."
                    value={newOwnerAddress}
                    onChange={(e) => setNewOwnerAddress(e.target.value)}
                    className="text-xs font-mono bg-secondary/20"
                  />
                  <p className="text-[10px] text-muted-foreground">
                    Current simulated owner: {localOwners[managementToken.id] ? `${localOwners[managementToken.id].slice(0, 6)}...` : shortAddress || "Active Wallet"}
                  </p>
                </div>

                <label className="flex items-start gap-2 pt-1 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={confirmTransfer}
                    onChange={(e) => setConfirmTransfer(e.target.checked)}
                    className="rounded border-border mt-0.5 text-primary focus:ring-primary h-3.5 w-3.5"
                  />
                  <span className="text-[11px] text-muted-foreground leading-snug">
                    I acknowledge that this action simulates an administrative ownership transfer locally under Architecture Decision D-06.
                  </span>
                </label>

                <DialogFooter className="pt-2">
                  <Button type="button" variant="outline" size="sm" onClick={() => setManagementToken(null)} className="text-xs">
                    Cancel
                  </Button>
                  <Button type="submit" size="sm" className="bg-primary hover:bg-primary/90 text-primary-foreground text-xs font-semibold">
                    <RotateCcw className="h-3.5 w-3.5 mr-1" /> Simulate Transfer
                  </Button>
                </DialogFooter>
              </form>
            )}
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
