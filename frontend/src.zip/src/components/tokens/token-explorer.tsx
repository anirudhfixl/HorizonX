"use client";

import React, { useState, useMemo } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { StatusBadge } from "@/components/shared/status-badge";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { MOCK_TOKENS } from "@/lib/mock-data";
import { Token, TokenMarketData } from "@/types";
import {
  Search,
  X,
  Plus,
  ArrowUpDown,
  ArrowUp,
  ArrowDown,
  ChevronLeft,
  ChevronRight,
  TrendingUp,
  TrendingDown,
  ShieldCheck,
  Info,
  Filter,
} from "lucide-react";

export type TokenWithMarket = Token & { market: TokenMarketData };

export type SortField = "name" | "price" | "marketCap" | "priceChange24h" | "volume24h";
export type SortOrder = "asc" | "desc";

interface TokenExplorerProps {
  mode?: "canonical" | "discovery";
}

/* ------------------------------------------------------------------ */
/* Pure helpers (no state)                                             */
/* ------------------------------------------------------------------ */

// Missing figures render as an em dash rather than a fabricated zero.
function formatCurrency(val?: number): string {
  if (val === undefined || val === null) return "—";
  if (val >= 1_000_000_000) return `$${(val / 1_000_000_000).toFixed(2)}B`;
  if (val >= 1_000_000) return `$${(val / 1_000_000).toFixed(2)}M`;
  if (val >= 1_000) return `$${(val / 1_000).toFixed(2)}K`;
  if (val < 0.01) return `$${val.toFixed(4)}`;
  return `$${val.toFixed(2)}`;
}

function formatPrice(val?: number): string {
  return val === undefined || val === null ? "—" : `$${val}`;
}

function formatChange(val?: number): string {
  if (val === undefined || val === null) return "—";
  return `${val >= 0 ? "+" : ""}${val}%`;
}

function isSepoliaNetwork(network: string): boolean {
  const n = network.toLowerCase();
  return n.includes("sepolia") || n === "ethereum";
}

const VERIFICATION_LABELS: Record<string, string> = {
  audit_available: "Audit available",
  contract_source_verified: "Source verified",
  project_reviewed: "Project reviewed",
  not_reviewed: "Not reviewed",
};

function verificationLabel(status?: string): string {
  if (!status) return "Not reviewed";
  return VERIFICATION_LABELS[status] ?? status.replace(/_/g, " ");
}

interface Filters {
  q: string;
  network: string;
  category: string;
  status: string;
}

// Single matching rule shared by the result list and the facet counts.
function tokenMatches(token: TokenWithMarket, f: Filters): boolean {
  const q = f.q.trim().toLowerCase();
  const matchesSearch =
    !q || token.name.toLowerCase().includes(q) || token.symbol.toLowerCase().includes(q);

  const matchesNetwork =
    f.network === "all"
      ? true
      : f.network === "sepolia"
      ? token.network.toLowerCase().includes("sepolia") || token.network.toLowerCase() === "ethereum"
      : token.network.toLowerCase() === f.network.toLowerCase();

  const matchesCategory =
    f.category === "all" ? true : (token.category || "").toLowerCase() === f.category.toLowerCase();

  const matchesStatus =
    f.status === "all" ? true : token.status.toLowerCase() === f.status.toLowerCase();

  return matchesSearch && matchesNetwork && matchesCategory && matchesStatus;
}

// Category identity tones, assigned by position in the sorted category list.
// Purely visual; carries no data meaning.
const TONES = [
  { tile: "border-primary/30 from-primary/25 to-primary/5", text: "text-primary" },
  { tile: "border-cyan-500/30 from-cyan-500/25 to-cyan-500/5", text: "text-cyan-400" },
  { tile: "border-violet-500/30 from-violet-500/25 to-violet-500/5", text: "text-violet-400" },
  { tile: "border-emerald-500/30 from-emerald-500/25 to-emerald-500/5", text: "text-emerald-400" },
  { tile: "border-rose-500/30 from-rose-500/25 to-rose-500/5", text: "text-rose-400" },
  { tile: "border-amber-500/30 from-amber-500/25 to-amber-500/5", text: "text-amber-400" },
];
const NEUTRAL_TONE = { tile: "border-border/60 from-secondary to-secondary/30", text: "text-muted-foreground" };

const SORT_LABELS: Record<SortField, string> = {
  marketCap: "Market cap",
  volume24h: "24h volume",
  priceChange24h: "24h change",
  price: "Price",
  name: "Name",
};

/* ------------------------------------------------------------------ */
/* Component                                                           */
/* ------------------------------------------------------------------ */

export function TokenExplorer({ mode = "canonical" }: TokenExplorerProps) {
  const router = useRouter();

  // Filter & Search State
  const [searchQuery, setSearchQuery] = useState("");
  const [networkFilter, setNetworkFilter] = useState("all");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState("all");

  // Sorting State
  const [sortField, setSortField] = useState<SortField>("marketCap");
  const [sortOrder, setSortOrder] = useState<SortOrder>("desc");

  // Pagination State
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(5);

  // Derive unique categories from mock records
  const uniqueCategories = useMemo(() => {
    const set = new Set<string>();
    MOCK_TOKENS.forEach((t) => {
      if (t.category) set.add(t.category);
    });
    return Array.from(set).sort();
  }, []);

  const toneOf = (token: TokenWithMarket) => {
    const idx = token.category ? uniqueCategories.indexOf(token.category) : -1;
    return idx < 0 ? NEUTRAL_TONE : TONES[idx % TONES.length];
  };

  // Filter Change Handlers with immediate page reset
  const handleSearchChange = (value: string) => {
    setSearchQuery(value);
    setCurrentPage(1);
  };
  const handleNetworkChange = (value: string) => {
    setNetworkFilter(value);
    setCurrentPage(1);
  };
  const handleCategoryChange = (value: string) => {
    setCategoryFilter(value);
    setCurrentPage(1);
  };
  const handleStatusChange = (value: string) => {
    setStatusFilter(value);
    setCurrentPage(1);
  };
  const handlePageSizeChange = (size: number) => {
    setPageSize(size);
    setCurrentPage(1);
  };

  // Handle sort column click
  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortOrder((prev) => (prev === "asc" ? "desc" : "asc"));
    } else {
      setSortField(field);
      setSortOrder(field === "name" ? "asc" : "desc");
    }
  };

  // Reset all filters
  const resetFilters = () => {
    setSearchQuery("");
    setNetworkFilter("all");
    setCategoryFilter("all");
    setStatusFilter("all");
    setSortField("marketCap");
    setSortOrder("desc");
    setCurrentPage(1);
  };

  const isFilteringActive =
    searchQuery.trim().length > 0 ||
    networkFilter !== "all" ||
    categoryFilter !== "all" ||
    statusFilter !== "all";

  // Filter Tokens
  const filteredTokens = useMemo(
    () => MOCK_TOKENS.filter((token) => tokenMatches(token, { q: searchQuery, network: networkFilter, category: categoryFilter, status: statusFilter })),
    [searchQuery, networkFilter, categoryFilter, statusFilter]
  );

  // Facet counts: each facet is counted with the other filters applied.
  const counts = useMemo(() => {
    const count = (o: Partial<Filters>) =>
      MOCK_TOKENS.filter((t) => tokenMatches(t, { q: searchQuery, network: networkFilter, category: categoryFilter, status: statusFilter, ...o })).length;
    return {
      category: (c: string) => count({ category: c }),
      network: (n: string) => count({ network: n }),
      status: (s: string) => count({ status: s }),
    };
  }, [searchQuery, networkFilter, categoryFilter, statusFilter]);

  // Sort Tokens
  const sortedTokens = useMemo(() => {
    return [...filteredTokens].sort((a, b) => {
      let valA: string | number = 0;
      let valB: string | number = 0;

      switch (sortField) {
        case "name":
          valA = a.name.toLowerCase();
          valB = b.name.toLowerCase();
          break;
        case "price":
          valA = a.market.price ?? 0;
          valB = b.market.price ?? 0;
          break;
        case "marketCap":
          valA = a.market.marketCap ?? 0;
          valB = b.market.marketCap ?? 0;
          break;
        case "priceChange24h":
          valA = a.market.priceChange24h ?? 0;
          valB = b.market.priceChange24h ?? 0;
          break;
        case "volume24h":
          valA = a.market.volume24h ?? 0;
          valB = b.market.volume24h ?? 0;
          break;
      }

      if (typeof valA === "string" && typeof valB === "string") {
        return sortOrder === "asc" ? valA.localeCompare(valB) : valB.localeCompare(valA);
      }

      const numA = Number(valA);
      const numB = Number(valB);
      return sortOrder === "asc" ? numA - numB : numB - numA;
    });
  }, [filteredTokens, sortField, sortOrder]);

  // Pagination calculation
  const totalResults = sortedTokens.length;
  const totalPages = Math.max(1, Math.ceil(totalResults / pageSize));
  const validCurrentPage = Math.min(currentPage, totalPages);
  const startIndex = (validCurrentPage - 1) * pageSize;
  const paginatedTokens = sortedTokens.slice(startIndex, startIndex + pageSize);

  // Landscape + scale references, all derived from the filtered set only.
  const landscape = useMemo(() => {
    const byCap = [...filteredTokens].sort((a, b) => (b.market.marketCap ?? 0) - (a.market.marketCap ?? 0));
    const totalCap = byCap.reduce((s, t) => s + (t.market.marketCap ?? 0), 0);
    const maxAbsChange = Math.max(0, ...filteredTokens.map((t) => Math.abs(t.market.priceChange24h ?? 0)));
    const maxCap = Math.max(0, ...filteredTokens.map((t) => t.market.marketCap ?? 0));
    const withChange = filteredTokens.filter((t) => typeof t.market.priceChange24h === "number");
    const gainer = [...withChange].sort((a, b) => (b.market.priceChange24h ?? 0) - (a.market.priceChange24h ?? 0))[0];
    const decliner = [...withChange].sort((a, b) => (a.market.priceChange24h ?? 0) - (b.market.priceChange24h ?? 0))[0];
    const busiest = [...filteredTokens]
      .filter((t) => typeof t.market.volume24h === "number")
      .sort((a, b) => (b.market.volume24h ?? 0) - (a.market.volume24h ?? 0))[0];
    return {
      byCap,
      totalCap,
      maxAbsChange,
      maxCap,
      gainer,
      decliner: decliner && (decliner.market.priceChange24h ?? 0) < 0 ? decliner : undefined,
      busiest,
    };
  }, [filteredTokens]);

  // Breadcrumbs based on route mode
  const crumbs =
    mode === "canonical"
      ? [{ label: "Tokens", href: "/tokens" }, { label: "Explore" }]
      : [{ label: "Explore", href: "/explore" }, { label: "Tokens" }];

  const SortIcon = ({ field }: { field: SortField }) =>
    sortField === field ? (
      sortOrder === "asc" ? (
        <ArrowUp className="h-3 w-3 text-primary" aria-hidden />
      ) : (
        <ArrowDown className="h-3 w-3 text-primary" aria-hidden />
      )
    ) : (
      <ArrowUpDown className="h-3 w-3 text-muted-foreground/40" aria-hidden />
    );

  const ariaSort = (field: SortField): "ascending" | "descending" | "none" =>
    sortField === field ? (sortOrder === "asc" ? "ascending" : "descending") : "none";

  const sortButton = (field: SortField, label: string, align: "left" | "right" = "right") => (
    <button
      type="button"
      onClick={() => handleSort(field)}
      className={cn(
        "inline-flex items-center gap-1.5 rounded text-[11px] font-semibold uppercase tracking-wider transition-colors hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary",
        sortField === field ? "text-foreground" : "text-muted-foreground",
        align === "right" && "ml-auto"
      )}
    >
      <span>{label}</span>
      <SortIcon field={field} />
    </button>
  );

  return (
    <div className="mx-auto w-full max-w-[1600px] space-y-10 px-4 py-10 sm:px-6 lg:px-10">
      {/* 1. Editorial header */}
      <header className="space-y-6">
        <nav aria-label="Breadcrumb" className="flex items-center gap-2 text-xs text-muted-foreground">
          {crumbs.map((c, i) => (
            <React.Fragment key={c.label}>
              {i > 0 && <span aria-hidden>/</span>}
              {c.href ? (
                <Link href={c.href} className="transition-colors hover:text-foreground">
                  {c.label}
                </Link>
              ) : (
                <span aria-current="page" className="text-foreground">
                  {c.label}
                </span>
              )}
            </React.Fragment>
          ))}
        </nav>

        <div className="flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
          <div className="max-w-3xl space-y-3">
            <p className="text-[11px] font-semibold uppercase tracking-[0.22em] text-primary">
              {mode === "canonical" ? "Tokens · Index" : "Explore · Token discovery"}
            </p>
            <h1 className="text-4xl font-semibold tracking-tight text-foreground sm:text-5xl">Token Explorer</h1>
            <p className="text-sm leading-relaxed text-muted-foreground sm:text-base">
              {mode === "canonical"
                ? "Comprehensive index of verified tokens, governance assets, and protocol liquidity across the ProMiners ecosystem."
                : "Cross-module token discovery index. Search, filter, and track verified contracts and simulated market telemetry."}
            </p>
          </div>
          <Button asChild size="sm" className="h-10 gap-1.5 self-start bg-primary px-4 text-sm font-semibold text-primary-foreground lg:self-auto">
            <Link href="/tokens/create">
              <Plus className="h-4 w-4" /> Deploy New Token
            </Link>
          </Button>
        </div>

        <div className="flex flex-col gap-3 border-l-2 border-primary/50 pl-4 text-xs leading-relaxed text-muted-foreground sm:flex-row sm:items-start sm:justify-between">
          <span className="flex items-start gap-2.5">
            <Info className="mt-0.5 h-3.5 w-3.5 shrink-0 text-primary" aria-hidden />
            <span>
              <strong className="text-foreground">Demonstration Data Notice:</strong> Token pricing, 24h percentage
              changes, market caps, and audit badges are simulated for demonstration. Per Architecture Decision{" "}
              <strong className="text-foreground">D-04</strong>, Ethereum Sepolia Testnet (Chain ID: 11155111) is the
              only approved and supported EVM network. Non-Sepolia tokens are preserved for cross-chain catalog
              discovery and do not imply wallet or contract support.
            </span>
          </span>
          <span className="shrink-0 self-start rounded-full border border-primary/30 px-2.5 py-0.5 font-mono text-[11px] text-primary">
            D-04: Sepolia (11155111) Only
          </span>
        </div>
      </header>

      {/* 2. Market landscape: segment width = simulated market cap, tint = 24h direction */}
      <section aria-label="Market landscape" className="space-y-4">
        <div className="flex flex-wrap items-end justify-between gap-x-8 gap-y-2">
          <div>
            <h2 className="text-[11px] font-semibold uppercase tracking-[0.2em] text-muted-foreground">
              Market landscape
            </h2>
            <p className="mt-1 text-xs text-muted-foreground">
              Width follows simulated market cap. Tint shows 24h direction. Select a segment to open the token.
            </p>
          </div>
          {landscape.byCap.length > 0 && (
            <p className="text-right text-xs text-muted-foreground">
              Combined simulated cap{" "}
              <span className="font-mono text-sm font-semibold text-foreground">{formatCurrency(landscape.totalCap)}</span>
              <span className="mx-2 text-border">|</span>
              <span className="font-mono text-foreground">{landscape.byCap.length}</span>{" "}
              {landscape.byCap.length === 1 ? "token" : "tokens"}
            </p>
          )}
        </div>

        {landscape.byCap.length === 0 ? (
          <div className="flex h-24 items-center justify-center rounded-2xl bg-secondary/20 text-xs text-muted-foreground">
            No tokens in the current view.
          </div>
        ) : (
          <>
            <div className="flex h-28 gap-0.5 overflow-hidden rounded-2xl sm:h-36">
              {landscape.byCap.map((t) => {
                const change = t.market.priceChange24h;
                const hasChange = typeof change === "number";
                const up = (change ?? 0) >= 0;
                const strength = landscape.maxAbsChange > 0 ? Math.abs(change ?? 0) / landscape.maxAbsChange : 0;
                const share = landscape.totalCap > 0 ? ((t.market.marketCap ?? 0) / landscape.totalCap) * 100 : 0;
                const tint = !hasChange
                  ? "bg-secondary/40 hover:bg-secondary/60"
                  : up
                  ? strength > 0.66
                    ? "bg-emerald-500/30 hover:bg-emerald-500/40"
                    : strength > 0.33
                    ? "bg-emerald-500/20 hover:bg-emerald-500/30"
                    : "bg-emerald-500/10 hover:bg-emerald-500/20"
                  : strength > 0.66
                  ? "bg-rose-500/30 hover:bg-rose-500/40"
                  : strength > 0.33
                  ? "bg-rose-500/20 hover:bg-rose-500/30"
                  : "bg-rose-500/10 hover:bg-rose-500/20";
                return (
                  <Link
                    key={t.id}
                    href={`/tokens/${t.id}`}
                    title={`${t.name} · ${formatCurrency(t.market.marketCap)} · ${formatChange(change)}`}
                    aria-label={`${t.name} (${t.symbol}), market cap ${formatCurrency(t.market.marketCap)}, 24h change ${formatChange(change)}`}
                    style={{ flexGrow: Math.max(t.market.marketCap ?? 0, 1), flexBasis: 0 }}
                    className={cn(
                      "group @container relative flex min-w-[2.25rem] flex-col justify-between overflow-hidden px-1 py-2.5 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-primary sm:min-w-[4rem] sm:px-3 sm:py-3.5",
                      tint
                    )}
                  >
                    <span className="truncate font-mono text-[9px] font-bold text-foreground sm:text-sm">{t.symbol}</span>
                    <span className="min-w-0 space-y-0.5">
                      <span
                        className={cn(
                          "flex items-center gap-1 truncate font-mono text-[9px] font-semibold sm:text-xs",
                          !hasChange ? "text-muted-foreground" : up ? "text-emerald-400" : "text-rose-400"
                        )}
                      >
                        {hasChange && (up ? <TrendingUp className="hidden h-3 w-3 shrink-0 @min-[5.5rem]:block" aria-hidden /> : <TrendingDown className="hidden h-3 w-3 shrink-0 @min-[5.5rem]:block" aria-hidden />)}
                        <span className="truncate">{formatChange(change)}</span>
                      </span>
                      <span className="hidden truncate font-mono text-[11px] text-muted-foreground @min-[7rem]:block">
                        {share.toFixed(share < 10 ? 1 : 0)}% of cap
                      </span>
                    </span>
                  </Link>
                );
              })}
            </div>

            <dl className="flex flex-wrap gap-x-10 gap-y-2 text-xs">
              {landscape.gainer && (
                <div className="flex items-baseline gap-2">
                  <dt className="text-muted-foreground">Top 24h gain</dt>
                  <dd className="font-mono text-foreground">
                    ${landscape.gainer.symbol}{" "}
                    <span className="text-emerald-400">{formatChange(landscape.gainer.market.priceChange24h)}</span>
                  </dd>
                </div>
              )}
              {landscape.decliner && (
                <div className="flex items-baseline gap-2">
                  <dt className="text-muted-foreground">Top 24h decline</dt>
                  <dd className="font-mono text-foreground">
                    ${landscape.decliner.symbol}{" "}
                    <span className="text-rose-400">{formatChange(landscape.decliner.market.priceChange24h)}</span>
                  </dd>
                </div>
              )}
              {landscape.busiest && (
                <div className="flex items-baseline gap-2">
                  <dt className="text-muted-foreground">Highest 24h volume</dt>
                  <dd className="font-mono text-foreground">
                    ${landscape.busiest.symbol}{" "}
                    <span className="text-muted-foreground">{formatCurrency(landscape.busiest.market.volume24h)}</span>
                  </dd>
                </div>
              )}
            </dl>
          </>
        )}
      </section>

      {/* 3. Command bar: search, network, status, category tabs */}
      <section aria-label="Search and filters" className="space-y-4">
        <div className="flex flex-col gap-3 xl:flex-row xl:items-center">
          <div className="relative min-w-0 flex-1">
            <Search className="pointer-events-none absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" aria-hidden />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => handleSearchChange(e.target.value)}
              placeholder="Search by token name or symbol (e.g., PMIN, Aurora, AURA)..."
              aria-label="Search tokens"
              className="h-12 w-full rounded-2xl border border-border/60 bg-secondary/40 pl-12 pr-11 text-sm text-foreground placeholder:text-muted-foreground/70 transition-colors focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => handleSearchChange("")}
                className="absolute right-3 top-1/2 -translate-y-1/2 rounded-full p-1.5 text-muted-foreground hover:bg-secondary hover:text-foreground"
                aria-label="Clear search"
              >
                <X className="h-4 w-4" />
              </button>
            )}
          </div>

          <div className="flex flex-wrap items-center gap-x-6 gap-y-3">
            <Segmented
              label="Network"
              value={networkFilter}
              onChange={handleNetworkChange}
              options={[
                { value: "all", label: "All", count: counts.network("all") },
                { value: "sepolia", label: "Sepolia", count: counts.network("sepolia"), hint: "Ethereum Sepolia (11155111), the only supported network per D-04" },
              ]}
            />
            <Segmented
              label="Status"
              value={statusFilter}
              onChange={handleStatusChange}
              options={[
                { value: "all", label: "All", count: counts.status("all") },
                { value: "active", label: "Active", count: counts.status("active") },
                { value: "pending", label: "Pending", count: counts.status("pending") },
              ]}
            />
          </div>
        </div>

        <div
          role="group"
          aria-label="Filter by category"
          className="-mx-4 flex gap-1.5 overflow-x-auto px-4 pb-1 sm:-mx-6 sm:px-6 lg:mx-0 lg:flex-wrap lg:overflow-visible lg:px-0 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden"
        >
          {[{ value: "all", label: "All categories", count: counts.category("all") }, ...uniqueCategories.map((c) => ({ value: c, label: c, count: counts.category(c) }))].map((c) => {
            const active = categoryFilter === c.value;
            const empty = c.count === 0 && !active;
            return (
              <button
                key={c.value}
                type="button"
                onClick={() => handleCategoryChange(c.value)}
                aria-pressed={active}
                className={cn(
                  "inline-flex shrink-0 items-center gap-2 rounded-full px-3.5 py-1.5 text-xs transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary",
                  active
                    ? "bg-primary font-semibold text-primary-foreground"
                    : empty
                    ? "text-muted-foreground/40 ring-1 ring-border/40 hover:text-muted-foreground"
                    : "text-muted-foreground ring-1 ring-border/60 hover:bg-secondary/50 hover:text-foreground"
                )}
              >
                {c.label}
                <span className={cn("font-mono text-[10px]", active ? "text-primary-foreground/70" : "text-muted-foreground/60")}>
                  {c.count}
                </span>
              </button>
            );
          })}
        </div>
      </section>

      {/* 4. Ledger */}
      <section aria-label="Token results" className="space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3 text-xs text-muted-foreground">
          <div className="flex flex-wrap items-center gap-3">
            <span aria-live="polite">
              Showing <strong className="text-foreground">{totalResults}</strong> {totalResults === 1 ? "token" : "tokens"}
            </span>
            {isFilteringActive && (
              <button
                type="button"
                onClick={resetFilters}
                className="inline-flex items-center gap-1 rounded-full px-2 py-1 text-[11px] text-muted-foreground ring-1 ring-border/60 hover:text-foreground"
              >
                <X className="h-3 w-3" /> Reset Filters
              </button>
            )}
          </div>

          <div className="flex flex-wrap items-center gap-4">
            <div className="flex items-center gap-2 lg:hidden">
              <label htmlFor="token-sort" className="text-[11px]">Sort by</label>
              <select
                id="token-sort"
                value={sortField}
                onChange={(e) => {
                  setSortField(e.target.value as SortField);
                  setSortOrder(e.target.value === "name" ? "asc" : "desc");
                }}
                className="rounded-lg border border-border/60 bg-secondary/40 px-2 py-1 text-xs text-foreground focus:outline-none focus:ring-1 focus:ring-primary"
              >
                {(Object.keys(SORT_LABELS) as SortField[]).map((f) => (
                  <option key={f} value={f}>{SORT_LABELS[f]}</option>
                ))}
              </select>
              <button
                type="button"
                onClick={() => setSortOrder((p) => (p === "asc" ? "desc" : "asc"))}
                aria-label={sortOrder === "asc" ? "Sort ascending, switch to descending" : "Sort descending, switch to ascending"}
                className="rounded-lg border border-border/60 bg-secondary/40 p-1.5 text-foreground"
              >
                {sortOrder === "asc" ? <ArrowUp className="h-3.5 w-3.5" /> : <ArrowDown className="h-3.5 w-3.5" />}
              </button>
            </div>

            <div className="flex items-center gap-2">
              <label htmlFor="token-page-size" className="text-[11px]">Rows per page:</label>
              <select
                id="token-page-size"
                value={pageSize}
                onChange={(e) => handlePageSizeChange(Number(e.target.value))}
                className="rounded-lg border border-border/60 bg-secondary/40 px-2 py-1 text-xs text-foreground focus:outline-none focus:ring-1 focus:ring-primary"
              >
                <option value={5}>5</option>
                <option value={10}>10</option>
                <option value={20}>20</option>
              </select>
            </div>
          </div>
        </div>

        {totalResults === 0 ? (
          <div className="flex flex-col items-center gap-4 border-y border-border/40 px-4 py-16 text-center">
            <Search className="h-8 w-8 text-primary/70" aria-hidden />
            <div className="space-y-1">
              <h3 className="text-base font-semibold text-foreground">No tokens matched your criteria</h3>
              <p className="mx-auto max-w-md text-sm text-muted-foreground">
                {searchQuery.trim()
                  ? `No tokens were found matching "${searchQuery}". Try adjusting your keywords or clearing your active filters.`
                  : "No tokens match the selected filters. Try clearing your active filters."}
              </p>
            </div>
            <Button onClick={resetFilters} size="sm" className="gap-1.5 bg-primary text-xs font-semibold text-primary-foreground">
              <Filter className="h-3.5 w-3.5" /> Clear All Filters
            </Button>
          </div>
        ) : (
          <>
            {/* Desktop ledger */}
            <div className="hidden overflow-x-auto lg:block">
              <table className="w-full min-w-[1000px] border-collapse text-left">
                <caption className="sr-only">
                  Tokens sorted by {SORT_LABELS[sortField]}, {sortOrder === "asc" ? "ascending" : "descending"}. Market figures are simulated.
                </caption>
                <thead>
                  <tr className="border-b border-border/60">
                    <th scope="col" className="w-12 py-3 pr-2 text-center text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">#</th>
                    <th scope="col" aria-sort={ariaSort("name")} className="py-3 pr-4">{sortButton("name", "Token", "left")}</th>
                    <th scope="col" className="py-3 pr-4 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">Network</th>
                    <th scope="col" aria-sort={ariaSort("price")} className="py-3 pr-4 text-right">{sortButton("price", "Price")}</th>
                    <th scope="col" aria-sort={ariaSort("priceChange24h")} className="w-44 py-3 pr-4 text-right">{sortButton("priceChange24h", "24h Change")}</th>
                    <th scope="col" aria-sort={ariaSort("volume24h")} className="py-3 pr-4 text-right">{sortButton("volume24h", "24h Volume")}</th>
                    <th scope="col" aria-sort={ariaSort("marketCap")} className="w-48 py-3 pr-4 text-right">{sortButton("marketCap", "Market Cap")}</th>
                    <th scope="col" className="py-3 pr-4 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">Status / Audit</th>
                    <th scope="col" className="w-10 py-3"><span className="sr-only">Details</span></th>
                  </tr>
                </thead>
                <tbody>
                  {paginatedTokens.map((token, index) => {
                    const rank = startIndex + index + 1;
                    const change = token.market.priceChange24h;
                    const hasChange = typeof change === "number";
                    const isPositive = (change ?? 0) >= 0;
                    const tone = toneOf(token);
                    const changeW = landscape.maxAbsChange > 0 ? (Math.abs(change ?? 0) / landscape.maxAbsChange) * 100 : 0;
                    const capW = landscape.maxCap > 0 ? ((token.market.marketCap ?? 0) / landscape.maxCap) * 100 : 0;
                    return (
                      <tr
                        key={token.id}
                        onClick={() => router.push(`/tokens/${token.id}`)}
                        className="group cursor-pointer border-b border-border/40 transition-colors hover:bg-secondary/30"
                      >
                        <td className="py-4 pr-2 text-center font-mono text-xs text-muted-foreground">{rank}</td>
                        <td className="py-4 pr-4">
                          <div className="flex items-center gap-3">
                            <span className={cn("flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border bg-gradient-to-br font-mono text-xs font-bold", tone.tile, tone.text)}>
                              {token.symbol.slice(0, 2)}
                            </span>
                            <span className="min-w-0">
                              <Link
                                href={`/tokens/${token.id}`}
                                onClick={(e) => e.stopPropagation()}
                                className="block truncate text-sm font-semibold text-foreground transition-colors hover:text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
                              >
                                {token.name}
                              </Link>
                              <span className="block truncate text-xs">
                                <span className="font-mono text-muted-foreground">${token.symbol}</span>
                                <span className="text-muted-foreground/50"> · </span>
                                <span className={cn("font-medium", tone.text)}>{token.category || "General"}</span>
                              </span>
                            </span>
                          </div>
                        </td>
                        <td className="py-4 pr-4">
                          <span className={cn("inline-flex items-center gap-1.5 font-mono text-xs", isSepoliaNetwork(token.network) ? "text-primary" : "text-muted-foreground")}>
                            <span className={cn("h-1.5 w-1.5 rounded-full", isSepoliaNetwork(token.network) ? "bg-primary" : "bg-muted-foreground/50")} aria-hidden />
                            {token.network}
                          </span>
                        </td>
                        <td className="py-4 pr-4 text-right font-mono text-sm font-semibold text-foreground">{formatPrice(token.market.price)}</td>
                        <td className="py-4 pr-4">
                          <div className="ml-auto flex w-36 flex-col items-end gap-1.5">
                            <span className={cn("inline-flex items-center gap-1 font-mono text-xs font-semibold", !hasChange ? "text-muted-foreground" : isPositive ? "text-emerald-400" : "text-rose-400")}>
                              {hasChange && (isPositive ? <TrendingUp className="h-3 w-3" aria-hidden /> : <TrendingDown className="h-3 w-3" aria-hidden />)}
                              {formatChange(change)}
                            </span>
                            <span className="h-1 w-full overflow-hidden rounded-full bg-secondary/60" aria-hidden>
                              <span className={cn("block h-full rounded-full", isPositive ? "bg-emerald-400/70" : "bg-rose-400/70")} style={{ width: `${changeW}%` }} />
                            </span>
                          </div>
                        </td>
                        <td className="py-4 pr-4 text-right font-mono text-xs text-muted-foreground">{formatCurrency(token.market.volume24h)}</td>
                        <td className="py-4 pr-4">
                          <div className="ml-auto flex w-40 flex-col items-end gap-1.5">
                            <span className="font-mono text-xs font-semibold text-foreground">{formatCurrency(token.market.marketCap)}</span>
                            <span className="h-1 w-full overflow-hidden rounded-full bg-secondary/60" aria-hidden>
                              <span className="block h-full rounded-full bg-primary/70" style={{ width: `${capW}%` }} />
                            </span>
                          </div>
                        </td>
                        <td className="py-4 pr-4">
                          <div className="flex flex-col items-start gap-1.5">
                            <StatusBadge status={token.status} />
                            <span className={cn("inline-flex items-center gap-1 text-[11px]", token.verificationStatus === "audit_available" ? "text-primary" : "text-muted-foreground")}>
                              {token.verificationStatus === "audit_available" && <ShieldCheck className="h-3 w-3" aria-hidden />}
                              {verificationLabel(token.verificationStatus)}
                            </span>
                          </div>
                        </td>
                        <td className="py-4 text-right">
                          <ChevronRight className="ml-auto h-4 w-4 text-muted-foreground/40 transition-all group-hover:translate-x-0.5 group-hover:text-primary" aria-hidden />
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* Tablet / mobile ledger */}
            <ul className="divide-y divide-border/40 border-y border-border/40 lg:hidden">
              {paginatedTokens.map((token, index) => {
                const rank = startIndex + index + 1;
                const change = token.market.priceChange24h;
                const hasChange = typeof change === "number";
                const isPositive = (change ?? 0) >= 0;
                const tone = toneOf(token);
                return (
                  <li key={token.id}>
                    <Link href={`/tokens/${token.id}`} className="block space-y-3 py-4 transition-colors hover:bg-secondary/20 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-primary">
                      <div className="flex items-center justify-between gap-3">
                        <div className="flex min-w-0 items-center gap-3">
                          <span className="w-4 shrink-0 text-center font-mono text-[11px] text-muted-foreground">{rank}</span>
                          <span className={cn("flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border bg-gradient-to-br font-mono text-xs font-bold", tone.tile, tone.text)}>
                            {token.symbol.slice(0, 2)}
                          </span>
                          <span className="min-w-0">
                            <span className="block truncate text-sm font-semibold text-foreground">{token.name}</span>
                            <span className="block truncate text-xs">
                              <span className="font-mono text-muted-foreground">${token.symbol}</span>
                              <span className="text-muted-foreground/50"> · </span>
                              <span className={cn("font-medium", tone.text)}>{token.category || "General"}</span>
                            </span>
                          </span>
                        </div>
                        <div className="shrink-0 text-right">
                          <span className="block font-mono text-sm font-semibold text-foreground">{formatPrice(token.market.price)}</span>
                          <span className={cn("inline-flex items-center gap-1 font-mono text-xs font-semibold", !hasChange ? "text-muted-foreground" : isPositive ? "text-emerald-400" : "text-rose-400")}>
                            {hasChange && (isPositive ? <TrendingUp className="h-3 w-3" aria-hidden /> : <TrendingDown className="h-3 w-3" aria-hidden />)}
                            {formatChange(change)}
                          </span>
                        </div>
                      </div>

                      <dl className="grid grid-cols-3 gap-3 pl-7 text-xs">
                        <div>
                          <dt className="text-[11px] text-muted-foreground">Market Cap</dt>
                          <dd className="font-mono text-foreground">{formatCurrency(token.market.marketCap)}</dd>
                        </div>
                        <div>
                          <dt className="text-[11px] text-muted-foreground">24h Volume</dt>
                          <dd className="font-mono text-foreground">{formatCurrency(token.market.volume24h)}</dd>
                        </div>
                        <div>
                          <dt className="text-[11px] text-muted-foreground">Network</dt>
                          <dd className={cn("truncate font-mono", isSepoliaNetwork(token.network) ? "text-primary" : "text-muted-foreground")}>{token.network}</dd>
                        </div>
                      </dl>

                      <div className="flex flex-wrap items-center gap-x-3 gap-y-1 pl-7">
                        <StatusBadge status={token.status} />
                        <span className={cn("inline-flex items-center gap-1 text-[11px]", token.verificationStatus === "audit_available" ? "text-primary" : "text-muted-foreground")}>
                          {token.verificationStatus === "audit_available" && <ShieldCheck className="h-3 w-3" aria-hidden />}
                          {verificationLabel(token.verificationStatus)}
                        </span>
                      </div>
                    </Link>
                  </li>
                );
              })}
            </ul>

            {/* Pagination */}
            <div className="flex flex-col gap-4 pt-2 sm:flex-row sm:items-center sm:justify-between">
              <div className="text-xs text-muted-foreground">
                Showing <strong className="text-foreground">{startIndex + 1}</strong>–
                <strong className="text-foreground">{Math.min(startIndex + pageSize, totalResults)}</strong> of{" "}
                <strong className="text-foreground">{totalResults}</strong> tokens (Page{" "}
                <strong className="text-foreground">{validCurrentPage}</strong> of{" "}
                <strong className="text-foreground">{totalPages}</strong>)
              </div>

              <nav aria-label="Pagination" className="flex items-center gap-1.5 self-center sm:self-auto">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                  disabled={validCurrentPage <= 1}
                  className="h-8 gap-1 px-2.5 text-xs"
                >
                  <ChevronLeft className="h-3.5 w-3.5" /> Previous
                </Button>

                <div className="flex items-center gap-1 px-1">
                  {Array.from({ length: totalPages }, (_, i) => i + 1).map((pageNumber) => (
                    <button
                      key={pageNumber}
                      type="button"
                      onClick={() => setCurrentPage(pageNumber)}
                      aria-label={`Page ${pageNumber}`}
                      aria-current={validCurrentPage === pageNumber ? "page" : undefined}
                      className={cn(
                        "h-8 w-8 rounded-full font-mono text-xs font-semibold transition-colors",
                        validCurrentPage === pageNumber
                          ? "bg-primary text-primary-foreground"
                          : "text-muted-foreground ring-1 ring-border/60 hover:bg-secondary/50 hover:text-foreground"
                      )}
                    >
                      {pageNumber}
                    </button>
                  ))}
                </div>

                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                  disabled={validCurrentPage >= totalPages}
                  className="h-8 gap-1 px-2.5 text-xs"
                >
                  Next <ChevronRight className="h-3.5 w-3.5" />
                </Button>
              </nav>
            </div>
          </>
        )}
      </section>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Local presentational helper                                         */
/* ------------------------------------------------------------------ */

function Segmented({
  label,
  options,
  value,
  onChange,
}: {
  label: string;
  options: { value: string; label: string; count: number; hint?: string }[];
  value: string;
  onChange: (value: string) => void;
}) {
  return (
    <div role="group" aria-label={`Filter by ${label.toLowerCase()}`} className="flex items-center gap-2.5">
      <span className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">{label}</span>
      <div className="flex rounded-full bg-secondary/40 p-0.5 ring-1 ring-border/60">
        {options.map((o) => {
          const active = value === o.value;
          return (
            <button
              key={o.value}
              type="button"
              onClick={() => onChange(o.value)}
              aria-pressed={active}
              title={o.hint}
              className={cn(
                "inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary",
                active ? "bg-primary font-semibold text-primary-foreground" : "text-muted-foreground hover:text-foreground"
              )}
            >
              {o.label}
              <span className={cn("font-mono text-[10px]", active ? "text-primary-foreground/70" : "text-muted-foreground/60")}>{o.count}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
