"use client";

import React, { useMemo, useSyncExternalStore } from "react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { StatusBadge } from "@/components/shared/status-badge";
import { useWallet } from "@/contexts/wallet-context";
import { useModal } from "@/contexts/modal-context";
import { MOCK_TOKENS } from "@/lib/mock-data";
import { Token, TokenMarketData } from "@/types";
import type { SimulatedTokenReceipt } from "@/components/tokens/token-creation-wizard";
import {
  Plus,
  Compass,
  ArrowRight,
  ArrowUpRight,
  Wallet,
  Info,
} from "lucide-react";

export type TokenWithMarket = Token & { market: TokenMarketData };

export interface TokensDashboardMetrics {
  totalTokens: number;
  activeTokens: number;
  pendingTokens: number;
  sepoliaTokens: number;
  catalogCrossChainTokens: number;
  totalMarketCap: number;
  totalVolume24h: number;
  totalLiquidity: number;
  topGainer?: TokenWithMarket;
  topMarketCapToken?: TokenWithMarket;
  categoryBreakdown: Record<string, number>;
  verificationBreakdown: Record<string, number>;
}

// Helper to format currency numbers compactly
export function formatCurrency(val?: number): string {
  if (val === undefined || val === null || val === 0) return "$0.00";
  if (val >= 1_000_000_000) return `$${(val / 1_000_000_000).toFixed(2)}B`;
  if (val >= 1_000_000) return `$${(val / 1_000_000).toFixed(2)}M`;
  if (val >= 1_000) return `$${(val / 1_000).toFixed(2)}K`;
  if (val < 0.01) return `$${val.toFixed(4)}`;
  return `$${val.toFixed(2)}`;
}

// Compute dashboard aggregations directly from the centralized token catalog
export function calculateTokensDashboardMetrics(
  tokens: TokenWithMarket[]
): TokensDashboardMetrics {
  const totalTokens = tokens.length;
  let activeTokens = 0;
  let pendingTokens = 0;
  let sepoliaTokens = 0;
  let catalogCrossChainTokens = 0;
  let totalMarketCap = 0;
  let totalVolume24h = 0;
  let totalLiquidity = 0;

  let topGainer: TokenWithMarket | undefined;
  let highestChange = -Infinity;

  let topMarketCapToken: TokenWithMarket | undefined;
  let highestCap = -Infinity;

  const categoryBreakdown: Record<string, number> = {};
  const verificationBreakdown: Record<string, number> = {};

  for (const t of tokens) {
    if (t.status === "active") activeTokens++;
    if (t.status === "pending") pendingTokens++;

    const isSepolia =
      t.network.toLowerCase().includes("sepolia") ||
      t.network.toLowerCase() === "ethereum";
    if (isSepolia) {
      sepoliaTokens++;
    } else {
      catalogCrossChainTokens++;
    }

    const cap = t.market?.marketCap || 0;
    const vol = t.market?.volume24h || 0;
    const liq = t.market?.liquidity || 0;
    const change = t.market?.priceChange24h || 0;

    totalMarketCap += cap;
    totalVolume24h += vol;
    totalLiquidity += liq;

    if (change > highestChange) {
      highestChange = change;
      topGainer = t;
    }

    if (cap > highestCap) {
      highestCap = cap;
      topMarketCapToken = t;
    }

    const cat = t.category || "Uncategorized";
    categoryBreakdown[cat] = (categoryBreakdown[cat] || 0) + 1;

    const ver = t.verificationStatus || "not_reviewed";
    verificationBreakdown[ver] = (verificationBreakdown[ver] || 0) + 1;
  }

  return {
    totalTokens,
    activeTokens,
    pendingTokens,
    sepoliaTokens,
    catalogCrossChainTokens,
    totalMarketCap,
    totalVolume24h,
    totalLiquidity,
    topGainer,
    topMarketCapToken,
    categoryBreakdown,
    verificationBreakdown,
  };
}

// Return the N most recently created tokens sorted by createdAt descending
export function getRecentlyAddedTokens(
  tokens: TokenWithMarket[],
  limit = 4
): TokenWithMarket[] {
  return [...tokens]
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, limit);
}

// Return curated flagship / highlighted tokens for feature display
export function getFeaturedTokens(tokens: TokenWithMarket[]): TokenWithMarket[] {
  // Key featured tokens: prominers (flagship), quantum (largest cap Sepolia), zkpv (privacy tier 1), ccat (top gainer)
  const featuredIds = ["prominers", "quantum", "zkpv", "ccat"];
  const found = tokens.filter((t) => featuredIds.includes(t.id));
  return found.length >= 3 ? found : tokens.slice(0, 4);
}

/* ─── Page-local helpers ─────────────────────────────────────────────────── */

const SESSION_KEY = "prominers_session_tokens";

function subscribeNoop() {
  return () => {};
}
function readSessionRaw(): string {
  try {
    return sessionStorage.getItem(SESSION_KEY) ?? "";
  } catch {
    return "";
  }
}

function isSepoliaNetwork(network: string): boolean {
  const n = network.toLowerCase();
  return n.includes("sepolia") || n === "ethereum";
}

function shortHex(addr?: string): string {
  if (!addr) return "—";
  return addr.length > 14 ? `${addr.slice(0, 6)}…${addr.slice(-4)}` : addr;
}

const VERIFICATION_LABEL: Record<string, string> = {
  audit_available: "Audit available",
  contract_source_verified: "Source verified",
  project_reviewed: "Project reviewed",
  not_reviewed: "Not reviewed",
};

const VERIFICATION_TONE: Record<string, string> = {
  audit_available: "text-emerald-400",
  contract_source_verified: "text-primary",
  project_reviewed: "text-sky-300",
  not_reviewed: "text-amber-400",
};

const CATEGORY_BARS = [
  "bg-chart-1",
  "bg-chart-2",
  "bg-chart-3",
  "bg-chart-4",
  "bg-chart-5",
  "bg-violet-400",
  "bg-muted-foreground/50",
];

interface Segment {
  key: string;
  label: string;
  count: number;
  bar: string;
}

/** One proportional strip plus a legend. Counts come straight from the catalog. */
function SegmentBar({ title, segments }: { title: string; segments: Segment[] }) {
  const shown = segments.filter((s) => s.count > 0);
  const total = shown.reduce((sum, s) => sum + s.count, 0);
  return (
    <div className="space-y-3">
      <div className="flex items-baseline justify-between">
        <h3 className="text-xs font-semibold uppercase tracking-[0.14em] text-muted-foreground">{title}</h3>
        <span className="font-mono text-[11px] text-muted-foreground">{total}</span>
      </div>
      <div
        role="img"
        aria-label={`${title}: ${shown.map((s) => `${s.label} ${s.count}`).join(", ")}`}
        className="flex h-2.5 w-full gap-0.5 overflow-hidden rounded-full"
      >
        {shown.map((s) => (
          <div key={s.key} style={{ flexGrow: s.count }} className={`basis-0 min-w-1 ${s.bar}`} />
        ))}
      </div>
      <ul className="space-y-1.5 text-xs">
        {shown.map((s) => (
          <li key={s.key} className="flex items-center gap-2">
            <span aria-hidden className={`h-2 w-2 shrink-0 rounded-full ${s.bar}`} />
            <span className="flex-1 truncate text-foreground/90">{s.label}</span>
            <span className="font-mono text-muted-foreground">{s.count}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

function SectionTitle({ index, title, aside }: { index: string; title: string; aside?: React.ReactNode }) {
  return (
    <div className="flex flex-wrap items-baseline justify-between gap-x-4 gap-y-1">
      <h2 className="flex items-baseline gap-3 text-lg font-bold tracking-tight text-foreground sm:text-xl">
        <span className="font-mono text-xs font-medium text-primary">{index}</span>
        {title}
      </h2>
      {aside}
    </div>
  );
}

const LEDGER_COLS =
  "md:grid-cols-[minmax(0,1.6fr)_minmax(0,1.1fr)_minmax(0,1fr)_minmax(0,1fr)]";

/* ─── Page ───────────────────────────────────────────────────────────────── */

export default function TokensDashboardPage() {
  const { isConnected, address, shortAddress, network, balance, isDemoMode } = useWallet();
  const { openModal } = useModal();

  const catalog = MOCK_TOKENS as TokenWithMarket[];

  const metrics = useMemo(() => calculateTokensDashboardMetrics(catalog), [catalog]);
  const recentTokens = useMemo(() => getRecentlyAddedTokens(catalog, 6), [catalog]);
  const byMarketCap = useMemo(
    () => [...catalog].sort((a, b) => (b.market?.marketCap ?? 0) - (a.market?.marketCap ?? 0)),
    [catalog],
  );
  const maxCap = Math.max(1, ...byMarketCap.map((t) => t.market?.marketCap ?? 0));

  // Ownership: catalog tokens whose creatorAddress equals the connected wallet (same rule as My Tokens)
  const owned = useMemo(() => {
    if (!address) return [];
    const a = address.toLowerCase();
    return catalog.filter((t) => t.creatorAddress?.toLowerCase() === a);
  }, [catalog, address]);

  // Simulated deployments created in this browser session via /tokens/create
  const sessionRaw = useSyncExternalStore(subscribeNoop, readSessionRaw, () => "");
  const sessionOwned = useMemo<SimulatedTokenReceipt[]>(() => {
    if (!address || !sessionRaw) return [];
    try {
      const parsed = JSON.parse(sessionRaw);
      if (!Array.isArray(parsed)) return [];
      const a = address.toLowerCase();
      return (parsed as SimulatedTokenReceipt[]).filter(
        (r) => r?.creatorAddress && r.creatorAddress.toLowerCase() === a,
      );
    } catch {
      return [];
    }
  }, [sessionRaw, address]);

  const ownedCount = owned.length + sessionOwned.length;

  const lifecycleOther = metrics.totalTokens - metrics.activeTokens - metrics.pendingTokens;
  const verificationKnown = ["audit_available", "contract_source_verified", "project_reviewed", "not_reviewed"];
  const verificationOther = Object.entries(metrics.verificationBreakdown)
    .filter(([k]) => !verificationKnown.includes(k))
    .reduce((s, [, v]) => s + v, 0);
  const categories = Object.entries(metrics.categoryBreakdown).sort((a, b) => b[1] - a[1]);

  return (
    <div className="mx-auto w-full max-w-[1800px] px-4 py-8 sm:px-6 lg:px-8">
      {/* ─── Header: a working toolbar, not a hero ─────────────────────── */}
      <header className="flex flex-col gap-6 border-b border-border/40 pb-8 md:flex-row md:items-end md:justify-between">
        <div className="space-y-2">
          <p className="font-mono text-xs text-muted-foreground">Tokens</p>
          <h1 className="text-3xl font-bold tracking-tight text-foreground sm:text-4xl">Token Dashboard</h1>
          <p className="max-w-xl text-sm leading-relaxed text-muted-foreground">
            Tokens you own, how the catalog is composed, and what was added recently. Create and manage
            ERC-20 contracts from here.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Button asChild variant="outline" size="sm" className="border-border/60 text-xs hover:bg-secondary/50">
            <Link href="/tokens/explore">
              <Compass className="mr-1 h-3.5 w-3.5 text-primary" /> Explore Catalog
            </Link>
          </Button>
          <Button asChild variant="outline" size="sm" className="border-border/60 text-xs hover:bg-secondary/50">
            <Link href="/tokens/my">
              <Wallet className="mr-1 h-3.5 w-3.5" /> My Tokens
            </Link>
          </Button>
          <Button
            asChild
            size="sm"
            className="gap-1.5 bg-primary text-xs font-semibold text-primary-foreground shadow-md shadow-primary/20 hover:bg-primary/90"
          >
            <Link href="/tokens/create">
              <Plus className="h-3.5 w-3.5" /> Create Token
            </Link>
          </Button>
        </div>
      </header>

      {/* Demonstration data + D-04 notice, kept as one honest line of context */}
      <p className="mt-5 flex gap-2.5 border-l-2 border-primary/60 py-0.5 pl-3 text-xs leading-relaxed text-muted-foreground">
        <Info className="mt-0.5 h-3.5 w-3.5 shrink-0 text-primary" />
        <span>
          Prices, 24h changes, volumes and liquidity on this page are simulated demonstration data. Per{" "}
          <strong className="font-semibold text-foreground/90">Architecture Decision D-04</strong>, Ethereum
          Sepolia (Chain ID 11155111) is the only active wallet network; other networks are catalog metadata
          and do not imply wallet or transaction support.
        </span>
      </p>

      {/* ─── 01 Ownership ledger + composition rail ────────────────────── */}
      <div className="mt-12 grid grid-cols-1 gap-12 lg:grid-cols-[minmax(0,1fr)_340px] lg:gap-16">
        <section aria-labelledby="owned-heading" className="space-y-5">
          <SectionTitle
            index="01"
            title="Your tokens"
            aside={
              isConnected ? (
                <span className="font-mono text-xs text-muted-foreground">
                  {owned.length} in catalog · {sessionOwned.length} simulated this session
                </span>
              ) : undefined
            }
          />
          <span id="owned-heading" className="sr-only">Tokens owned by the connected wallet</span>

          {/* column header row, shared by every state so the ledger shape is always visible */}
          <div
            className={`hidden gap-4 border-b border-border/50 pb-2 font-mono text-[10px] uppercase tracking-wider text-muted-foreground md:grid ${LEDGER_COLS}`}
          >
            <span>Token</span>
            <span>Status</span>
            <span>Supply</span>
            <span>Contract</span>
          </div>

          {!isConnected ? (
            <div className="space-y-4 rounded-lg border border-dashed border-border/60 px-5 py-10 text-center md:text-left">
              <p className="text-sm font-medium text-foreground">Connect a wallet to see tokens you own</p>
              <p className="max-w-lg text-xs leading-relaxed text-muted-foreground">
                The ledger lists contracts whose creator address matches your wallet, plus any simulated
                deployments you made in this session.
              </p>
              <div className="flex flex-wrap items-center justify-center gap-3 md:justify-start">
                <Button
                  size="sm"
                  onClick={() => openModal("CONNECT_WALLET")}
                  className="bg-primary text-xs font-semibold text-primary-foreground hover:bg-primary/90"
                >
                  <Wallet className="mr-1.5 h-3.5 w-3.5" /> Connect Wallet
                </Button>
                <Link href="/tokens/explore" className="text-xs font-semibold text-primary hover:underline">
                  Or browse the catalog →
                </Link>
              </div>
            </div>
          ) : ownedCount === 0 ? (
            <div className="space-y-4 rounded-lg border border-dashed border-border/60 px-5 py-10 text-center md:text-left">
              <p className="text-sm font-medium text-foreground">No tokens deployed from {shortAddress}</p>
              <p className="max-w-lg text-xs leading-relaxed text-muted-foreground">
                Nothing in the catalog or this session was created by this address yet.
              </p>
              <Button
                asChild
                size="sm"
                className="gap-1.5 bg-primary text-xs font-semibold text-primary-foreground hover:bg-primary/90"
              >
                <Link href="/tokens/create">
                  <Plus className="h-3.5 w-3.5" /> Create your first token
                </Link>
              </Button>
            </div>
          ) : (
            <ul className="divide-y divide-border/40">
              {owned.map((t) => (
                <li key={t.id} className={`grid grid-cols-1 gap-x-4 gap-y-3 py-5 md:items-center ${LEDGER_COLS}`}>
                  <Link href={`/tokens/${t.id}`} className="group flex min-w-0 items-center gap-3">
                    <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-primary/15 font-bold text-primary transition-colors group-hover:bg-primary group-hover:text-primary-foreground">
                      {t.symbol.slice(0, 2)}
                    </span>
                    <span className="min-w-0">
                      <span className="block truncate text-sm font-semibold text-foreground group-hover:text-primary">
                        {t.name}
                      </span>
                      <span className="block font-mono text-[11px] text-muted-foreground">
                        ${t.symbol} · {t.standard ?? "ERC-20"} · {isSepoliaNetwork(t.network) ? "Sepolia" : t.network}
                      </span>
                    </span>
                  </Link>
                  <div className="space-y-1">
                    <StatusBadge status={t.status} />
                    <span
                      className={`block text-[11px] ${VERIFICATION_TONE[t.verificationStatus ?? "not_reviewed"] ?? "text-muted-foreground"}`}
                    >
                      {VERIFICATION_LABEL[t.verificationStatus ?? "not_reviewed"] ?? "Not reviewed"}
                    </span>
                  </div>
                  <div className="font-mono text-sm text-foreground">
                    {t.totalSupply ?? "—"}
                    <span className="ml-1 text-[11px] text-muted-foreground">{t.symbol}</span>
                  </div>
                  <div className="space-y-1.5">
                    <span className="block font-mono text-[11px] text-muted-foreground">{shortHex(t.contractAddress)}</span>
                    <span className="flex flex-wrap gap-x-3 gap-y-1 text-[11px] font-semibold">
                      <Link href={`/tokens/${t.id}/contract`} className="text-primary hover:underline">Contract</Link>
                      <Link href={`/tokens/${t.id}/activity`} className="text-primary hover:underline">Activity</Link>
                      <Link href="/tokens/my" className="text-primary hover:underline">Manage</Link>
                    </span>
                  </div>
                </li>
              ))}

              {sessionOwned.map((r) => (
                <li
                  key={r.contractAddress}
                  className={`grid grid-cols-1 gap-x-4 gap-y-3 py-5 md:items-center ${LEDGER_COLS}`}
                >
                  <div className="flex min-w-0 items-center gap-3">
                    <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border border-dashed border-primary/50 font-bold text-primary">
                      {r.symbol.slice(0, 2)}
                    </span>
                    <span className="min-w-0">
                      <span className="block truncate text-sm font-semibold text-foreground">{r.name}</span>
                      <span className="block font-mono text-[11px] text-muted-foreground">
                        ${r.symbol} · ERC-20 · {r.network}
                      </span>
                    </span>
                  </div>
                  <div className="space-y-1">
                    <span className="inline-block rounded border border-amber-500/30 bg-amber-500/10 px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-amber-400">
                      Simulated · this session
                    </span>
                    <span className="block text-[11px] text-muted-foreground">Deployed {r.deployedAt}</span>
                  </div>
                  <div className="font-mono text-sm text-foreground">
                    {r.totalSupply}
                    <span className="ml-1 text-[11px] text-muted-foreground">{r.symbol}</span>
                  </div>
                  <div className="space-y-1.5">
                    <span className="block font-mono text-[11px] text-muted-foreground">{shortHex(r.contractAddress)}</span>
                    <Link href="/tokens/my" className="text-[11px] font-semibold text-primary hover:underline">
                      Manage
                    </Link>
                  </div>
                </li>
              ))}
            </ul>
          )}

          {isConnected && ownedCount > 0 && (
            <Link
              href="/tokens/my"
              className="inline-flex items-center gap-1 text-xs font-semibold text-primary hover:underline"
            >
              Open My Tokens to mint, burn and manage <ArrowRight className="h-3.5 w-3.5" />
            </Link>
          )}
        </section>

        {/* Composition rail */}
        <aside aria-label="Wallet and catalog composition" className="space-y-9 lg:border-l lg:border-border/40 lg:pl-10">
          <div className="space-y-3">
            <h3 className="text-xs font-semibold uppercase tracking-[0.14em] text-muted-foreground">Wallet</h3>
            {isConnected ? (
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="font-mono text-base font-semibold text-foreground">{shortAddress}</span>
                  {isDemoMode && (
                    <span className="rounded bg-primary/15 px-1.5 py-0.5 text-[10px] font-semibold uppercase text-primary">
                      Demo
                    </span>
                  )}
                </div>
                <p className="font-mono text-xs text-muted-foreground">
                  {balance} ETH · {network.name}
                </p>
              </div>
            ) : (
              <p className="text-xs leading-relaxed text-muted-foreground">
                Not connected. Wallet network: Ethereum Sepolia only (D-04).
              </p>
            )}
          </div>

          <SegmentBar
            title="Catalog status"
            segments={[
              { key: "active", label: "Active", count: metrics.activeTokens, bar: "bg-emerald-400" },
              { key: "pending", label: "Pending", count: metrics.pendingTokens, bar: "bg-amber-400" },
              { key: "other", label: "Other", count: lifecycleOther, bar: "bg-muted-foreground/50" },
            ]}
          />

          <SegmentBar
            title="Verification"
            segments={[
              { key: "audit_available", label: "Audit available", count: metrics.verificationBreakdown["audit_available"] ?? 0, bar: "bg-emerald-400" },
              { key: "contract_source_verified", label: "Source verified", count: metrics.verificationBreakdown["contract_source_verified"] ?? 0, bar: "bg-primary" },
              { key: "project_reviewed", label: "Project reviewed", count: metrics.verificationBreakdown["project_reviewed"] ?? 0, bar: "bg-sky-300" },
              { key: "not_reviewed", label: "Not reviewed", count: metrics.verificationBreakdown["not_reviewed"] ?? 0, bar: "bg-amber-400" },
              { key: "other", label: "Other", count: verificationOther, bar: "bg-muted-foreground/50" },
            ]}
          />

          <SegmentBar
            title="Network (D-04)"
            segments={[
              { key: "sepolia", label: "Ethereum Sepolia", count: metrics.sepoliaTokens, bar: "bg-primary" },
              { key: "cross", label: "Catalog only, other networks", count: metrics.catalogCrossChainTokens, bar: "bg-muted-foreground/50" },
            ]}
          />

          <SegmentBar
            title="Category"
            segments={categories.map(([cat, count], i) => ({
              key: cat,
              label: cat,
              count,
              bar: CATEGORY_BARS[Math.min(i, CATEGORY_BARS.length - 1)],
            }))}
          />
        </aside>
      </div>

      {/* ─── 02 Timeline + 03 Market-cap ranking ───────────────────────── */}
      <div className="mt-16 grid grid-cols-1 gap-14 border-t border-border/40 pt-14 lg:grid-cols-2 lg:gap-16">
        <section aria-label="Recently cataloged tokens" className="space-y-6">
          <SectionTitle
            index="02"
            title="Recently cataloged"
            aside={
              <Link href="/tokens/explore" className="text-xs font-semibold text-primary hover:underline">
                Explore all {metrics.totalTokens} →
              </Link>
            }
          />
          <ol className="relative space-y-0 border-l border-border/60 pl-6">
            {recentTokens.map((t) => (
              <li key={t.id} className="relative pb-7 last:pb-0">
                <span
                  aria-hidden
                  className="absolute -left-[31px] top-1.5 h-2.5 w-2.5 rounded-full bg-background ring-2 ring-primary"
                />
                <p className="font-mono text-[11px] text-muted-foreground">{t.createdAt}</p>
                <div className="mt-1 flex flex-wrap items-baseline justify-between gap-x-4 gap-y-1">
                  <Link
                    href={`/tokens/${t.id}`}
                    className="text-sm font-semibold text-foreground transition-colors hover:text-primary"
                  >
                    {t.name} <span className="font-mono text-xs font-normal text-muted-foreground">${t.symbol}</span>
                  </Link>
                  <Link
                    href={`/tokens/${t.id}/activity`}
                    className="inline-flex items-center gap-0.5 text-[11px] font-semibold text-primary hover:underline"
                  >
                    Activity <ArrowUpRight className="h-3 w-3" />
                  </Link>
                </div>
                <p className="mt-0.5 text-xs text-muted-foreground">
                  Added to the catalog · {t.standard ?? "ERC-20"} · {isSepoliaNetwork(t.network) ? "Ethereum Sepolia (D-04)" : t.network}
                </p>
              </li>
            ))}
          </ol>
        </section>

        <section aria-label="Simulated market capitalization ranking" className="space-y-6">
          <SectionTitle
            index="03"
            title="Market cap ranking"
            aside={
              <span className="rounded bg-muted px-2 py-0.5 font-mono text-[10px] text-muted-foreground">
                Simulated · total {formatCurrency(metrics.totalMarketCap)}
              </span>
            }
          />
          <ul className="space-y-1">
            {byMarketCap.map((t) => {
              const cap = t.market?.marketCap ?? 0;
              const change = t.market?.priceChange24h;
              const up = (change ?? 0) >= 0;
              return (
                <li key={t.id}>
                  <Link
                    href={`/tokens/${t.id}`}
                    className="group grid grid-cols-[3.75rem_minmax(0,1fr)_9.5rem] items-center gap-x-3 rounded-md px-1 py-2 transition-colors hover:bg-white/[0.03]"
                  >
                    <span className="font-mono text-xs font-bold text-foreground group-hover:text-primary">{t.symbol}</span>
                    <span className="h-2 overflow-hidden rounded-full bg-secondary">
                      <span
                        className="block h-full rounded-full bg-gradient-to-r from-primary/70 to-primary"
                        style={{ width: `${Math.max(2, Math.round((cap / maxCap) * 100))}%` }}
                      />
                    </span>
                    <span className="flex items-baseline justify-end gap-2 text-right font-mono text-xs">
                      <span className="text-foreground">{formatCurrency(cap)}</span>
                      <span className={`w-14 ${up ? "text-emerald-400" : "text-rose-400"}`}>
                        {typeof change === "number" ? `${up ? "+" : ""}${change}%` : "—"}
                      </span>
                    </span>
                  </Link>
                </li>
              );
            })}
          </ul>
        </section>
      </div>
    </div>
  );
}
