import Link from "next/link";
import {
  ArrowRight,
  ArrowUpRight,
  Blocks,
  Coins,
  Gift,
  Layers3,
  Rocket,
  ShieldCheck,
  Sparkles,
  Wallet,
} from "lucide-react";
import { EarthHero } from "@/components/home/earth-hero";
import { GoogleGeminiEffectDemo } from "@/components/home/google-gemini-effect-demo";
import { CardSpotlight } from "@/components/ui/card-spotlight";
import { WalletConnectSection } from "@/components/home/wallet-connect-section";

const capabilities = [
  {
    number: "01",
    icon: Coins,
    title: "Create",
    description: "Create and deploy a token with a clear, guided workflow. Configure the essentials and move from concept to contract.",
    href: "/tokens/create",
    action: "Create a token",
    spotlight: "rgba(139, 92, 246, 0.16)",
    colors: [[139, 92, 246], [99, 102, 241]],
  },
  {
    number: "02",
    icon: Rocket,
    title: "Launch",
    description: "Bring your project to market with launch and presale tools designed to make each step easier to understand.",
    href: "/launchpad",
    action: "Explore launch tools",
    spotlight: "rgba(99, 102, 241, 0.16)",
    colors: [[99, 102, 241], [59, 130, 246]],
  },
  {
    number: "03",
    icon: Gift,
    title: "Activate",
    description: "Reward participation and build momentum with community campaigns and airdrop distribution.",
    href: "/airdrops",
    action: "Explore campaigns",
    spotlight: "rgba(168, 85, 247, 0.16)",
    colors: [[168, 85, 247], [217, 70, 239]],
  },
  {
    number: "04",
    icon: Layers3,
    title: "Expand",
    description: "Keep your community involved after launch with staking and ongoing ecosystem participation.",
    href: "/staking",
    action: "Explore staking",
    spotlight: "rgba(129, 140, 248, 0.16)",
    colors: [[129, 140, 248], [139, 92, 246]],
  },
];

const principles = [
  {
    icon: Blocks,
    title: "A connected project journey",
    description: "Move from token creation to launch and community growth without piecing together a stack of unrelated tools.",
  },
  {
    icon: Wallet,
    title: "Your wallet, your control",
    description: "Explore freely. Connect your wallet when you are ready to create, manage or participate.",
  },
  {
    icon: ShieldCheck,
    title: "Understand before you act",
    description: "Keep the important project details and participation mechanics clear at every step.",
  },
];

export default function Home() {
  return (
    <main className="min-w-0 overflow-hidden bg-[#080711] text-[#f4f1ff]">
      <EarthHero />

      <div className="relative bg-[radial-gradient(ellipse_75%_420px_at_50%_0%,rgba(112,85,190,.12),transparent_75%),#080711]">
        <GoogleGeminiEffectDemo />

        <section className="relative w-full px-5 pb-8 pt-3 sm:px-8 sm:pb-10 lg:px-12 lg:pt-5">
          <div className="mx-auto max-w-[1600px]">
            <div className="mb-8 grid gap-5 sm:mb-9 lg:mb-10">
              <div className="max-w-[900px]">
                <div className="mb-5 flex items-center gap-3">
                  <span className="h-px w-8 bg-violet-300/70" />
                  <p className="text-[10px] font-bold uppercase tracking-[.28em] text-violet-300/85">
                    The HorizonX ecosystem
                  </p>
                </div>
                <h2 className="text-balance text-[clamp(2.65rem,4.4vw,4.75rem)] font-medium leading-[1.01] tracking-[-.067em] text-white">
                  From first token to
                  <span className="mt-1 block bg-gradient-to-r from-violet-100 via-violet-200 to-indigo-200 bg-clip-text text-transparent">
                    a growing ecosystem.
                  </span>
                </h2>
              </div>
            </div>

            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-4 xl:gap-4">
              {capabilities.map((item) => {
                const Icon = item.icon;
                return (
                  <CardSpotlight
                    key={item.number}
                    radius={230}
                    color={item.spotlight}
                    colors={item.colors}
                    className="min-h-[300px] rounded-[22px] border border-white/[.09] bg-[linear-gradient(155deg,rgba(25,20,42,.94),rgba(11,9,21,.98)_62%)] p-0 shadow-[inset_0_1px_0_rgba(255,255,255,.035)] transition-[border-color,transform,box-shadow] duration-500 hover:-translate-y-1 hover:border-violet-200/20 hover:shadow-[0_18px_55px_rgba(0,0,0,.22)] sm:min-h-[315px] xl:min-h-[330px]"
                  >
                    <Link
                      href={item.href}
                      className="group relative z-10 flex h-full min-h-[300px] flex-col p-6 outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-violet-300 sm:min-h-[315px] sm:p-7 xl:min-h-[330px] xl:p-7 2xl:p-8"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-mono text-[10px] font-semibold tracking-[.2em] text-violet-300/65">{item.number}</span>
                        <span className="grid h-11 w-11 place-items-center rounded-[15px] border border-violet-200/15 bg-violet-200/[.07] text-violet-100 shadow-[inset_0_1px_0_rgba(255,255,255,.06)] transition-all duration-500 group-hover:-translate-y-1 group-hover:border-violet-200/35 group-hover:bg-violet-200/[.13] group-hover:shadow-[0_0_30px_rgba(139,92,246,.16)]">
                          <Icon className="h-[19px] w-[19px]" strokeWidth={1.65} />
                        </span>
                      </div>

                      <div className="mt-8">
                        <h3 className="text-[22px] font-semibold tracking-[-.045em] text-white transition-colors duration-300 group-hover:text-violet-100">{item.title}</h3>
                        <p className="mt-3 max-w-[300px] text-[12px] leading-[1.85] text-[#aaa5bd] sm:text-[12.5px]">
                          {item.description}
                        </p>
                      </div>

                      <span className="mt-auto flex items-center gap-2 pt-7 text-[11px] font-semibold text-violet-200/90 transition-colors duration-300 group-hover:text-white">
                        {item.action}
                        <ArrowUpRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1 group-hover:-translate-y-1" />
                      </span>
                      <span aria-hidden className="pointer-events-none absolute inset-x-6 bottom-5 h-px origin-left scale-x-0 bg-gradient-to-r from-violet-300/70 via-indigo-300/40 to-transparent transition-transform duration-500 group-hover:scale-x-100 sm:inset-x-7 2xl:inset-x-8" />
                    </Link>
                  </CardSpotlight>
                );
              })}
            </div>
            <p className="mx-auto mt-7 max-w-full text-center text-base leading-7 tracking-[-.015em] text-[#bcb6d0] sm:mt-8 sm:text-lg sm:leading-8 xl:whitespace-nowrap">
              Four connected capabilities. One place to build, launch and grow your Web3 project.
            </p>
          </div>
        </section>

        <section className="relative mx-auto grid max-w-[1440px] grid-cols-1 gap-14 px-5 py-20 sm:px-8 lg:grid-cols-[.85fr_1.15fr] lg:items-center lg:gap-24 lg:px-12 lg:py-28">
          <div>
            <p className="mb-4 text-[10px] font-bold uppercase tracking-[.25em] text-violet-300/85">Built around the journey</p>
            <h2 className="text-balance text-3xl font-medium leading-[1.12] tracking-[-.055em] text-white sm:text-4xl lg:text-[50px]">
              More than tools.
              <span className="block text-violet-200">A place to build.</span>
            </h2>
            <p className="mt-6 max-w-[470px] text-sm leading-7 text-[#aaa6bd]">
              HorizonX brings the key stages of a Web3 project into one connected experience.
              Start with what you need now, then use the ecosystem as your project evolves.
            </p>
            <Link
              href="/explore"
              className="mt-8 inline-flex min-h-12 items-center justify-center gap-3 rounded-full border border-violet-200/25 bg-violet-300/[.08] px-6 text-[12px] font-semibold text-violet-100 shadow-[inset_0_1px_0_rgba(255,255,255,.06)] transition-all hover:border-violet-200/45 hover:bg-violet-300/[.14] hover:text-white"
            >
              Explore HorizonX <ArrowRight className="h-4 w-4" />
            </Link>
          </div>

          <div className="relative">
            <div aria-hidden className="absolute -inset-8 rounded-[40px] bg-violet-500/[.06] blur-3xl" />
            <div className="relative divide-y divide-white/[.09] border-y border-white/[.09]">
              {principles.map((item, index) => {
                const Icon = item.icon;
                return (
                  <div key={item.title} className="group flex gap-5 py-7 first:pt-8 last:pb-8 sm:gap-6">
                    <div className="mt-0.5 grid h-12 w-12 shrink-0 place-items-center rounded-2xl border border-violet-200/15 bg-violet-200/[.07] text-violet-100 transition-colors group-hover:bg-violet-200/[.12]">
                      <Icon className="h-5 w-5" strokeWidth={1.6} />
                    </div>
                    <div className="min-w-0">
                      <div className="flex flex-wrap items-center gap-3">
                        <span className="font-mono text-[10px] tracking-wider text-violet-300/60">0{index + 1}</span>
                        <h3 className="text-[15px] font-semibold tracking-tight text-white">{item.title}</h3>
                      </div>
                      <p className="mt-2 max-w-[530px] text-[13px] leading-7 text-[#aaa6bd]">{item.description}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </section>

        <section className="relative px-5 pb-20 sm:px-8 lg:px-12 lg:pb-28">
          <div className="relative mx-auto max-w-[1440px] overflow-hidden border border-violet-200/15 bg-[radial-gradient(ellipse_at_50%_0%,rgba(139,92,246,.2),transparent_65%),linear-gradient(125deg,#171329,#0e0c1b_58%,#0a0913)] px-6 py-16 text-center sm:px-12 sm:py-20 lg:py-24">
            <div aria-hidden className="pointer-events-none absolute -left-24 -top-32 h-72 w-72 rounded-full bg-violet-500/10 blur-3xl" />
            <div aria-hidden className="pointer-events-none absolute -bottom-36 -right-16 h-80 w-80 rounded-full bg-indigo-500/10 blur-3xl" />
            <div className="relative">
              <span className="mx-auto grid h-12 w-12 place-items-center rounded-2xl border border-violet-200/20 bg-violet-200/[.08] text-violet-100">
                <Sparkles className="h-5 w-5" />
              </span>
              <p className="mt-7 text-[10px] font-bold uppercase tracking-[.25em] text-violet-200/75">Your next move starts here</p>
              <h2 className="mx-auto mt-4 max-w-[760px] text-balance text-3xl font-medium tracking-[-.055em] text-white sm:text-5xl lg:text-[58px]">
                Have an idea worth launching?
              </h2>
              <p className="mx-auto mt-5 max-w-[540px] text-sm leading-7 text-[#b4aec8]">
                Start creating with HorizonX, or explore the ecosystem before you make your move.
              </p>
              <div className="mt-9 flex flex-wrap items-center justify-center gap-3">
                <Link href="/tokens/create" className="inline-flex min-h-12 items-center justify-center gap-2 rounded-full border border-[#f5f1ff] bg-[#f5f1ff] px-6 text-[12px] font-bold text-[#100c1c] shadow-[0_8px_28px_rgba(167,139,250,.16)] transition-all hover:-translate-y-0.5 hover:bg-violet-100">
                  <Rocket className="h-4 w-4" /> Launch a token <ArrowRight className="h-4 w-4" />
                </Link>
                <Link href="/explore" className="inline-flex min-h-12 items-center justify-center gap-2 rounded-full border border-white/20 bg-white/[.04] px-6 text-[12px] font-semibold text-white transition-all hover:-translate-y-0.5 hover:bg-white/[.09]">
                  Explore first <ArrowUpRight className="h-4 w-4" />
                </Link>
              </div>
            </div>
          </div>
          <p className="mx-auto mt-7 max-w-3xl text-center text-[10px] leading-5 text-[#777187]">
            Always review project details and on-chain terms before participating. Digital assets involve risk.
          </p>
        </section>
      </div>

      <WalletConnectSection />
    </main>
  );
}
