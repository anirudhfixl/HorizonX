// Hybrid Data Provider for HorizonX
// Integrates live CoinMarketCap market data with local HorizonX ecosystem datasets.
// Keeps projects, airdrops, launchpad, staking, partners and news on local provider.
// Normalizes external responses into existing TypeScript models.
// Provides graceful fallback to local data if CoinMarketCap API key is missing or unconfigured.

import type {
  IDataProvider,
  ITokenProvider,
  IProjectProvider,
  IAirdropProvider,
  ILaunchpadProvider,
  IStakingProvider,
  IMarketProvider,
  IExchangeProvider,
  IPartnerProvider,
  INewsProvider,
} from './data-provider';
import { localDataProvider } from './local-provider';
import { cmcClient } from '../client/cmc-client';
import type {
  Token,
  TokenFilters,
  TokenSortParams,
  Project,
  ProjectFilters,
  ProjectSortParams,
  AirdropCampaign,
  AirdropFilters,
  AirdropSortParams,
  Presale,
  FairLaunch,
  LaunchpadItem,
  LaunchpadFilters,
  LaunchpadSortParams,
  StakingPool,
  StakingFilters,
  StakingSortParams,
  MarketOverview,
  MarketPair,
  MarketFilters,
  MarketSortParams,
  MarketHistoryPoint,
  ExchangeOrderBook,
  ExchangeTrade,
  PartnerItem,
  PartnerProgramMetrics,
  PartnerBenefit,
  PartnerFilters,
  PartnerSortParams,
  NewsArticle,
  NewsFilters,
  NewsSortParams,
  PaginatedResult,
  PaginationParams,
} from '../types';

function paginate<T>(items: T[], pagination?: PaginationParams): PaginatedResult<T> {
  const page = Math.max(1, pagination?.page || 1);
  const pageSize = Math.max(1, pagination?.pageSize || (items.length > 0 ? items.length : 10));
  const total = items.length;
  const totalPages = Math.max(1, Math.ceil(total / pageSize));
  const startIndex = (page - 1) * pageSize;
  const pageItems = items.slice(startIndex, startIndex + pageSize);

  return {
    items: pageItems,
    pagination: {
      page,
      pageSize,
      total,
      totalPages,
      hasNextPage: page < totalPages,
      hasPrevPage: page > 1,
    },
  };
}

class HybridTokenProvider implements ITokenProvider {
  async list(filters?: TokenFilters, pagination?: PaginationParams, sort?: TokenSortParams): Promise<PaginatedResult<Token>> {
    try {
      // Attempt live CMC listings
      const cmcTokens = await cmcClient.getListings({
        limit: 100,
        sort: sort?.sortBy === 'volume24h' ? 'volume_24h' : sort?.sortBy === 'priceChange24h' ? 'percent_change_24h' : 'market_cap',
        sortDir: sort?.sortOrder || 'desc',
      });

      if (!cmcTokens || cmcTokens.length === 0) {
        return localDataProvider.tokens.list(filters, pagination, sort);
      }

      // Also get local ecosystem tokens so local projects remain accessible
      const localResult = await localDataProvider.tokens.list();
      const localTokens = localResult.items;

      // Tag local ecosystem tokens clearly so they are distinguishable from external market tokens
      const taggedLocalTokens: Token[] = localTokens.map((t) => ({
        ...t,
        isEcosystem: true,
        isExternal: false,
        origin: 'ecosystem',
        market: {
          ...t.market,
          source: 'HorizonX Ecosystem (Simulated)',
          isLive: false,
        },
      } as Token));

      // Tag external CoinMarketCap tokens clearly
      const taggedCmcTokens: Token[] = cmcTokens.map((t) => ({
        ...t,
        isEcosystem: false,
        isExternal: true,
        origin: 'external',
        market: {
          ...t.market,
          source: 'CoinMarketCap',
          isLive: true,
        },
      } as Token));

      // Merge: unique by symbol / id without replacing or dropping local tokens
      const seenSymbols = new Set<string>();
      const seenIds = new Set<string>();
      const combined: Token[] = [];

      // Add live CoinMarketCap external tokens
      for (const ct of taggedCmcTokens) {
        const sym = ct.symbol.toUpperCase();
        if (!seenSymbols.has(sym) && !seenIds.has(ct.id)) {
          seenSymbols.add(sym);
          seenIds.add(ct.id);
          combined.push(ct);
        }
      }

      // Add HorizonX ecosystem tokens (preserving all existing records)
      for (const lt of taggedLocalTokens) {
        const sym = lt.symbol.toUpperCase();
        if (!seenSymbols.has(sym) && !seenIds.has(lt.id)) {
          seenSymbols.add(sym);
          seenIds.add(lt.id);
          combined.push(lt);
        } else if (!seenIds.has(lt.id)) {
          // If a symbol collides, preserve local ecosystem token with unique id
          seenIds.add(lt.id);
          combined.push(lt);
        }
      }

      // Default sort by market cap descending if no sort specified
      if (!sort?.sortBy) {
        combined.sort((a, b) => ((b.market?.marketCap ?? b.marketCap ?? 0) - (a.market?.marketCap ?? a.marketCap ?? 0)));
      }

      // Apply filtering
      let filtered = combined;
      if (filters?.search) {
        const q = filters.search.toLowerCase().trim();
        filtered = filtered.filter(
          (t) =>
            t.name.toLowerCase().includes(q) ||
            t.symbol.toLowerCase().includes(q) ||
            t.id.toLowerCase().includes(q)
        );
      }

      if (filters?.category && filters.category.length > 0) {
        const cats = filters.category.map((c) => c.toLowerCase());
        filtered = filtered.filter((t) => t.category && cats.includes(t.category.toLowerCase()));
      }

      if (filters?.minPrice !== undefined) {
        filtered = filtered.filter((t) => (t.price ?? 0) >= filters.minPrice!);
      }
      if (filters?.maxPrice !== undefined) {
        filtered = filtered.filter((t) => (t.price ?? 0) <= filters.maxPrice!);
      }
      if (filters?.minMarketCap !== undefined) {
        filtered = filtered.filter((t) => (t.marketCap ?? 0) >= filters.minMarketCap!);
      }

      // Apply sorting
      if (sort?.sortBy) {
        const field = sort.sortBy;
        const dir = sort.sortOrder === 'asc' ? 1 : -1;
        filtered.sort((a, b) => {
          let aVal: any = (a as any)[field];
          let bVal: any = (b as any)[field];
          if (aVal === undefined && a.market) aVal = (a.market as any)[field];
          if (bVal === undefined && b.market) bVal = (b.market as any)[field];

          if (typeof aVal === 'string') {
            return dir * aVal.localeCompare(String(bVal || ''));
          }
          return dir * ((Number(aVal) || 0) - (Number(bVal) || 0));
        });
      }

      return paginate(filtered, pagination);
    } catch {
      // Graceful fallback to local catalog
      return localDataProvider.tokens.list(filters, pagination, sort);
    }
  }

  async getById(id: string): Promise<Token | null> {
    try {
      // Check local catalog first if it matches an ecosystem token
      const localToken = await localDataProvider.tokens.getById(id);
      if (localToken) return localToken;

      // Query CoinMarketCap proxy
      const cmcToken = await cmcClient.getTokenDetail(id);
      if (cmcToken) return cmcToken;

      return null;
    } catch {
      return localDataProvider.tokens.getById(id);
    }
  }

  async search(query: string, limit = 10): Promise<Token[]> {
    const list = await this.list({ search: query }, { page: 1, pageSize: limit });
    return list.items;
  }

  async getFeatured(): Promise<Token[]> {
    try {
      const localFeatured = await localDataProvider.tokens.getFeatured();
      const cmcListings = await cmcClient.getListings({ limit: 5 });
      const seen = new Set<string>(localFeatured.map((t) => t.id));
      const result = [...localFeatured];
      for (const ct of cmcListings) {
        if (!seen.has(ct.id)) {
          seen.add(ct.id);
          result.push(ct);
        }
      }
      return result.slice(0, 8);
    } catch {
      return localDataProvider.tokens.getFeatured();
    }
  }
}

class HybridMarketProvider implements IMarketProvider {
  async getOverview(): Promise<MarketOverview> {
    try {
      return await cmcClient.getOverview();
    } catch {
      return localDataProvider.market.getOverview();
    }
  }

  async listPairs(filters?: MarketFilters, pagination?: PaginationParams, sort?: MarketSortParams): Promise<PaginatedResult<MarketPair>> {
    try {
      const listings = await cmcClient.getListings({ limit: 40 });
      if (!listings || listings.length === 0) {
        return localDataProvider.market.listPairs(filters, pagination, sort);
      }

      const pairs: MarketPair[] = listings.map((token) => ({
        id: `${token.symbol}-USD`,
        symbol: `${token.symbol}/USD`,
        name: `${token.name} / US Dollar`,
        baseTokenId: token.id,
        quoteSymbol: 'USD',
        price: token.price ?? 0,
        priceChange24h: token.priceChange24h ?? 0,
        volume24h: token.volume24h ?? 0,
        liquidity: (token.marketCap ?? 0) * 0.05,
        high24h: (token.price ?? 0) * 1.05,
        low24h: (token.price ?? 0) * 0.95,
        category: token.category,
        network: token.network,
      }));

      // Append local pairs
      const localPairs = await localDataProvider.market.listPairs();
      for (const lp of localPairs.items) {
        if (!pairs.some((p) => p.symbol === lp.symbol)) {
          pairs.push(lp);
        }
      }

      let filtered = pairs;
      if (filters?.search) {
        const q = filters.search.toLowerCase().trim();
        filtered = filtered.filter((p) => p.symbol.toLowerCase().includes(q) || p.name.toLowerCase().includes(q));
      }
      if (filters?.quoteSymbol) {
        filtered = filtered.filter((p) => p.quoteSymbol.toUpperCase() === filters.quoteSymbol?.toUpperCase());
      }
      if (filters?.minVolume !== undefined) {
        filtered = filtered.filter((p) => p.volume24h >= filters.minVolume!);
      }
      if (filters?.minLiquidity !== undefined) {
        filtered = filtered.filter((p) => p.liquidity >= filters.minLiquidity!);
      }

      if (sort?.sortBy) {
        const field = sort.sortBy;
        const dir = sort.sortOrder === 'asc' ? 1 : -1;
        filtered.sort((a, b) => {
          const aVal = (a as any)[field] ?? 0;
          const bVal = (b as any)[field] ?? 0;
          return dir * (aVal - bVal);
        });
      }

      return paginate(filtered, pagination);
    } catch {
      return localDataProvider.market.listPairs(filters, pagination, sort);
    }
  }

  async getPairBySymbol(symbol: string): Promise<MarketPair | null> {
    try {
      const pairs = await this.listPairs();
      const normalized = symbol.toUpperCase().replace('-', '/');
      const found = pairs.items.find((p) => p.symbol.toUpperCase() === normalized || p.id.toUpperCase() === symbol.toUpperCase());
      if (found) return found;
      return localDataProvider.market.getPairBySymbol(symbol);
    } catch {
      return localDataProvider.market.getPairBySymbol(symbol);
    }
  }

  async getHistoricalData(tokenId: string, range?: '24h' | '7d' | '30d' | '90d'): Promise<MarketHistoryPoint[]> {
    return localDataProvider.market.getHistoricalData(tokenId, range);
  }
}

class HybridExchangeProvider implements IExchangeProvider {
  async getOverview(): Promise<MarketOverview> {
    try {
      return await cmcClient.getOverview();
    } catch {
      return localDataProvider.exchange.getOverview();
    }
  }

  async listMarkets(filters?: MarketFilters, pagination?: PaginationParams, sort?: MarketSortParams): Promise<PaginatedResult<MarketPair>> {
    const marketProvider = new HybridMarketProvider();
    return marketProvider.listPairs(filters, pagination, sort);
  }

  async getMarketByTokenId(tokenId: string): Promise<MarketPair | null> {
    const marketProvider = new HybridMarketProvider();
    const pairs = await marketProvider.listPairs();
    const found = pairs.items.find((p) => p.baseTokenId === tokenId || p.id.toLowerCase().includes(tokenId.toLowerCase()));
    if (found) return found;
    return localDataProvider.exchange.getMarketByTokenId(tokenId);
  }

  async getOrderBook(symbol: string): Promise<ExchangeOrderBook> {
    try {
      const marketProvider = new HybridMarketProvider();
      const pair = await marketProvider.getPairBySymbol(symbol);
      const basePrice = pair?.price || 100;

      const bids = Array.from({ length: 10 }, (_, i) => ({
        price: Number((basePrice * (1 - (i + 1) * 0.003)).toFixed(4)),
        amount: Number((Math.random() * 5 + 0.5).toFixed(2)),
        total: 0,
      }));
      let runningBidTotal = 0;
      bids.forEach((b) => {
        runningBidTotal += b.amount * b.price;
        b.total = Number(runningBidTotal.toFixed(2));
      });

      const asks = Array.from({ length: 10 }, (_, i) => ({
        price: Number((basePrice * (1 + (i + 1) * 0.003)).toFixed(4)),
        amount: Number((Math.random() * 5 + 0.5).toFixed(2)),
        total: 0,
      }));
      let runningAskTotal = 0;
      asks.forEach((a) => {
        runningAskTotal += a.amount * a.price;
        a.total = Number(runningAskTotal.toFixed(2));
      });

      return {
        symbol: pair?.symbol || 'BTC/USD',
        bids,
        asks,
        lastPrice: basePrice,
        spread: Number((asks[0].price - bids[0].price).toFixed(4)),
      };
    } catch {
      return localDataProvider.exchange.getOrderBook(symbol);
    }
  }

  async getRecentTrades(symbol: string, limit = 20): Promise<ExchangeTrade[]> {
    return localDataProvider.exchange.getRecentTrades(symbol, limit);
  }
}

export class HybridDataProvider implements IDataProvider {
  readonly id = 'hybrid';
  readonly name = 'Hybrid Provider (CoinMarketCap + HorizonX Ecosystem)';

  public tokens: ITokenProvider;
  public market: IMarketProvider;
  public exchange: IExchangeProvider;

  // Local ecosystem domains strictly preserved on local provider
  public projects: IProjectProvider = localDataProvider.projects;
  public airdrops: IAirdropProvider = localDataProvider.airdrops;
  public launchpad: ILaunchpadProvider = localDataProvider.launchpad;
  public staking: IStakingProvider = localDataProvider.staking;
  public partners: IPartnerProvider = localDataProvider.partners;
  public news: INewsProvider = localDataProvider.news;

  constructor() {
    this.tokens = new HybridTokenProvider();
    this.market = new HybridMarketProvider();
    this.exchange = new HybridExchangeProvider();
  }
}

export const hybridDataProvider = new HybridDataProvider();

