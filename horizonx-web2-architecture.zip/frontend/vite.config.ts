import { fileURLToPath, URL } from "node:url";
import { defineConfig, loadEnv } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";

function marketApiPlugin() {
  return {
    name: "market-api-dev-proxy",
    configureServer(server: any) {
      server.middlewares.use("/api/market", async (req: any, res: any, next: any) => {
        try {
          const { handleMarketRequest } = await import("./api/market-handler");
          await handleMarketRequest(req, res);
        } catch (err) {
          next(err);
        }
      });
    },
  };
}

// https://vite.dev/config/
export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), "");
  if (env.COINMARKETCAP_API_KEY && !process.env.COINMARKETCAP_API_KEY) {
    process.env.COINMARKETCAP_API_KEY = env.COINMARKETCAP_API_KEY;
  }

  return {
    plugins: [react(), tailwindcss(), marketApiPlugin()],
    resolve: {
      alias: {
        "@": fileURLToPath(new URL("./src", import.meta.url)),
      },
    },
    // Some wallet SDKs (MetaMask, WalletConnect) expect a Node-style `global` in the browser.
    define: {
      global: "globalThis",
    },
    server: {
      port: 3000,
    },
    preview: {
      port: 3000,
    },
  };
});
